// Public endpoint only. Provider credentials must never be placed in this file.
export const CLOUD_API_BASE = 'https://insightflow-api.viorchas.workers.dev';
