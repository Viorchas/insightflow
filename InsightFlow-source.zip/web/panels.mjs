import { requirementFields } from './product-panels.mjs';
import { renameTopic, setTopicStatus, updateRequirement, validateBackup, mergeBackup } from './workspace.mjs';
import { projectOf, effective, isReviewed, saveState } from './demo-model.mjs';

export function createPanels({getState,setState,commit,openModal,modal,esc,btn,tag,render,toast,formError,isBusy}) {
  const attempt=fn=>{try{fn();}catch(e){formError(e);}};
  function requirementEditor(id) {
    const p=projectOf(getState()),r=p.requirements.find(r=>r.id===id);
    if(!r)throw new Error('需求不存在。');
    const oldIds=new Set(r.sources.map(s=>s.id));
    const choices=[...r.sources.map(s=>({id:s.id,content:s.content,existing:true})),...p.feedback.filter(f=>effective(f)&&!oldIds.has(f.id)).map(f=>({...f,existing:false}))];
    openModal('编辑需求与来源',`<form id="edit-requirement"><label>需求标题<input name="title" required maxlength="120" value="${esc(r.title)}"></label><label>需求描述<textarea name="description" rows="4" maxlength="5000">${esc(r.description)}</textarea></label><label>优先级<select name="priority">${[['unset','未设置'],['low','低'],['medium','中'],['high','高']].map(([v,l])=>`<option value="${v}" ${r.priority===v?'selected':''}>${l}</option>`).join('')}</select></label>${requirementFields(esc,r)}<h3 class="field-label">来源反馈（至少保留 1 条，最多 200 条）</h3><p class="footnote">保留的来源仍使用原快照；新增来源保存当前快照。取消勾选可移除关联，不删除原反馈。</p><div class="source-list">${choices.map(f=>`<div><label class="checkbox-label"><input type="checkbox" name="sources" value="${f.id}" ${f.existing?'checked':''}>${esc(f.content)}</label>${tag(f.existing?'已有来源快照':isReviewed(f)?'新增·已审核':'新增·未审核')}</div>`).join('')}</div><label class="checkbox-label"><input type="checkbox" name="acknowledge">若新增来源包含未审核建议，我已查看并确认关联。</label><div class="form-actions">${btn('close','取消','secondary')}<button type="submit" class="btn primary">保存需求与来源</button></div></form>`,true);
    document.querySelector('#edit-requirement').addEventListener('submit',e=>{e.preventDefault();attempt(()=>{const data=new FormData(e.target);commit(p=>updateRequirement(p,id,r.revision,{...Object.fromEntries(data),title:data.get('title'),description:data.get('description'),priority:data.get('priority')},data.getAll('sources'),data.has('acknowledge')));modal.close();render();toast('需求内容与来源已保存。');});});
  }
  function topicEditor(id) {
    const p=projectOf(getState()),t=p.topics.find(t=>t.id===id);
    if(!t)throw new Error('主题不存在。');
    openModal('管理主题',`<form id="edit-topic"><label>主题名称<input name="name" required minlength="2" maxlength="30" value="${esc(t.name)}"></label><p class="footnote">改名保持主题 ID 不变，关联需求的历史快照保留原名称。重名会阻止保存，不自动合并。</p><div class="form-actions"><button class="btn primary" type="submit">保存名称</button></div></form><hr><p>归档保留历史分类与统计，但不参与新的 AI 或关键词匹配；可以恢复。</p>${btn(t.status==='archived'?'restore-topic':'archive-topic',t.status==='archived'?'恢复为已确认主题':'归档此主题','secondary',`data-id="${id}" data-revision="${t.revision||0}"`)}`);
    document.querySelector('#edit-topic').addEventListener('submit',e=>{e.preventDefault();attempt(()=>{const name=new FormData(e.target).get('name');commit(p=>renameTopic(p,id,t.revision||0,name));modal.close();render();toast('主题名称已保存。');});});
  }
  function topicStatus(id,revision,status) {
    commit(p=>setTopicStatus(p,id,revision,status));modal.close();render();toast(status==='archived'?'主题已归档，历史数据保留。':'主题已恢复。');
  }
  function history() {
    const p=projectOf(getState());
    openModal('导入历史',p.imports.length?`<div class="table-scroll"><table><thead><tr><th>文件与时间</th><th>总行数</th><th>新增</th><th>错误</th><th>跳过</th><th></th></tr></thead><tbody>${p.imports.map(b=>`<tr><td>${esc(b.fileName)}<small class="subtle">${esc(new Date(b.createdAt).toLocaleString('zh-CN',{timeZone:'Asia/Hong_Kong'}))}</small></td><td>${b.total}</td><td>${b.imported}</td><td>${b.invalid}</td><td>${b.skipped}</td><td>${btn('import-history-detail','查看明细','text',`data-id="${b.id}"`)}</td></tr>`).join('')}</tbody></table></div>`:'<p>还没有导入记录。示例预设数据不计作实际导入。</p>',true);
  }
  function historyDetail(id) {
    const batch=projectOf(getState()).imports.find(b=>b.id===id);if(!batch)throw new Error('导入批次不存在。');
    const rows=batch.rows||[];
    openModal('导入批次明细',`<h3>${esc(batch.fileName)}</h3><p>总计 ${batch.total} · 新增 ${batch.imported} · 错误 ${batch.invalid} · 跳过 ${batch.skipped}</p><p class="footnote">${rows.length?'记录号按原 CSV 数据记录保留；导入完成与分析状态分别记录。':'旧版批次没有逐行明细，仅保留汇总。'}</p><div class="preview-scroll"><table><thead><tr><th>记录号</th><th>结果</th><th>错误原因</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.recordNo)}</td><td>${esc({new:'已导入',duplicate:'重复跳过',invalid:'无效',empty:'空行跳过'}[r.outcome]||r.outcome)}</td><td>${esc((r.errors||[]).join('；')||'—')}</td></tr>`).join('')}</tbody></table></div>${btn('import-history','返回历史','secondary')}`,true);
  }
  function restore() {
    if(isBusy())throw new Error('请等待真实分析结束，再恢复备份。');
    openModal('恢复浏览器备份',`<p>选择 InsightFlow 导出的 JSON（最多 10 MiB）。先校验内容和关联，恢复为新项目；不会覆盖当前项目。备份可能含反馈原文，请妥善保管。</p><label class="btn secondary file-label">选择备份文件<input id="backup-file" type="file" accept=".json,application/json"></label>`);
    document.querySelector('#backup-file').addEventListener('change',async e=>{
      try {
        const file=e.target.files[0];if(!file)return;
        if(file.size>10*1024*1024)throw new Error('备份不能超过 10 MiB。');
        let parsed;try{parsed=JSON.parse(await file.text());}catch{throw new Error('JSON 文件损坏，未恢复任何数据。');}
        const clean=validateBackup(parsed);
        openModal('确认恢复备份',`<p>已校验 ${clean.projects.length} 个项目、${clean.projects.reduce((n,p)=>n+p.feedback.length,0)} 条反馈。将新增带“（恢复）”后缀的项目，原数据不变。</p><div class="form-actions">${btn('close','取消','secondary')}<button id="confirm-restore" class="btn primary">确认添加备份项目</button></div>`);
        document.querySelector('#confirm-restore').addEventListener('click',()=>attempt(()=>{
          if(isBusy())throw new Error('分析进行中，请稍后恢复。');
          const next=mergeBackup(getState(),clean);saveState(localStorage,next);setState(next);modal.close();render();toast('备份已恢复为独立项目。');
        }));
      }catch(e){formError(e);}
    });
  }
  const runLabels={running:'处理中',completed:'已完成',partial_failed:'部分失败',failed:'全部失败',interrupted:'已中断',stopped:'已停止'};
  const itemLabels={queued:'未开始',running:'请求中',succeeded:'已保存结果',failed:'失败',unknown:'结果未知（可能已计费）',not_started:'未发送'};
  function analysisHistory(){
    const runs=projectOf(getState()).analysisRuns||[];
    openModal('真实分析记录',`<p class="footnote">本浏览器最多保留最近 50 轮。刷新中断的请求不会自动重试；未知结果可能已计费。此记录不等同于服务器后台队列。</p>${runs.length?`<div class="source-list">${runs.map(r=>`<div>${tag(runLabels[r.status]||r.status)} ${esc(new Date(r.createdAt).toLocaleString('zh-CN',{timeZone:'Asia/Hong_Kong'}))}<p>${r.items.length} 条 · 已保存 ${r.items.filter(i=>i.status==='succeeded').length} 条</p>${btn('analysis-history-detail','查看逐条状态','text',`data-id="${r.id}"`)}</div>`).join('')}</div>`:'<p>尚无从本页面发起的真实分析记录。接口连通测试不计入此处。</p>'}`,true);
  }
  function analysisHistoryDetail(id){
    const p=projectOf(getState()),run=(p.analysisRuns||[]).find(r=>r.id===id);if(!run)throw new Error('分析记录不存在。');
    openModal('分析逐条状态',`<div class="source-list">${run.items.map(i=>`<div>${tag(itemLabels[i.status]||i.status)}<p>${esc(p.feedback.find(f=>f.id===i.id)?.content||'原反馈不可用')}</p>${i.error?`<p class="form-error">${esc(i.error)}</p>`:''}</div>`).join('')}</div>${btn('analysis-history','返回分析记录','secondary')}`,true);
  }
  return {requirementEditor,topicEditor,topicStatus,history,historyDetail,restore,analysisHistory,analysisHistoryDetail};
}
