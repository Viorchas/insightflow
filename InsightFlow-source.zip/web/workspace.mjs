import { uid, effective, isReviewed, snapshot, SCHEMA_VERSION } from './demo-model.mjs';
const normalized = text => text.normalize('NFKC').trim().replace(/\s+/gu,' ').toLowerCase();
const text = (v,min,max) => typeof v==='string' && [...v.trim()].length>=min && [...v].length<=max;
const id = v=>typeof v==='string'&&/^[a-zA-Z0-9_-]{1,100}$/.test(v);
function conflict(entity, revision) {if(!entity || (entity.revision||0)!==revision)throw new Error('内容已变化，请重新打开后操作。');}
export function renameTopic(project, topicId, revision, name) {
  const topic=project.topics.find(t=>t.id===topicId);conflict(topic,revision);
  if(!text(name,2,30))throw new Error('主题名称需为 2—30 字符。');
  if(project.topics.some(t=>t.id!==topicId&&normalized(t.name)===normalized(name)))throw new Error('主题名称已存在，不会自动合并。');
  topic.name=name.trim();topic.revision=(topic.revision||0)+1;
}
export function setTopicStatus(project, topicId, revision, status) {
  const topic=project.topics.find(t=>t.id===topicId);conflict(topic,revision);
  if(!['confirmed','archived'].includes(status))throw new Error('不支持的主题状态。');
  if(status==='confirmed'&&topic.status!=='confirmed'&&project.topics.filter(t=>t.status==='confirmed').length>=100)throw new Error('已确认主题已达 100 个上限。');
  if(topic.status!==status){topic.previousStatus=topic.status;topic.status=status;topic.revision=(topic.revision||0)+1;}
}
export function updateRequirement(project, reqId, revision, fields, sourceIds, acknowledge=false) {
  const req=project.requirements.find(r=>r.id===reqId);conflict(req,revision);
  if(!text(fields.title,1,120)||!text(fields.description||'',0,5000)||!['unset','low','medium','high'].includes(fields.priority))throw new Error('请检查标题、描述长度和优先级。');
  if(!sourceIds.length||sourceIds.length>200||new Set(sourceIds).size!==sourceIds.length)throw new Error('必须保留 1—200 条不重复的来源。');
  const old=new Map(req.sources.map(s=>[s.id,s]));
  const additions=sourceIds.filter(id=>!old.has(id)).map(id=>project.feedback.find(f=>f.id===id));
  if(additions.some(f=>!f||!effective(f)))throw new Error('新增来源不存在或没有有效分类。');
  if(additions.some(f=>!isReviewed(f))&&!acknowledge)throw new Error('新增来源包含未审核建议，请确认已查看原文。');
  const sources=sourceIds.map(id=>old.get(id)||snapshot(project.feedback.find(f=>f.id===id),project.topics));
  Object.assign(req,{title:fields.title.trim(),description:fields.description||'',priority:fields.priority,sources,revision:req.revision+1,updatedAt:new Date().toISOString()});
}
export function matchesFeedback(f, params) {
  const get=key=>params instanceof URLSearchParams?params.get(key):params[key];
  if(get('q')&&!f.content.toLowerCase().includes(get('q').toLowerCase()))return false;
  if(get('topic')&&f.topicId!==get('topic'))return false;
  if(get('review')&&f.review!==get('review'))return false;
  if(get('analysis')&&f.analysisStatus!==get('analysis'))return false;
  if(get('scope')==='reviewed'&&!isReviewed(f))return false;
  if((get('topic')||get('scope'))&&!effective(f))return false;
  if(get('from')&&(!f.date||f.date<get('from')))return false;
  if(get('to')&&(!f.date||f.date>get('to')))return false;
  return true;
}

export function recoverInterruptedRuns(state, now=Date.now(), excludeId=null) {
  let changed=false;
  for(const p of state.projects)for(const run of p.analysisRuns||[]){
    if(run.status==='running' && run.id!==excludeId && now-Date.parse(run.updatedAt||run.createdAt||0)>60_000){
      run.status='interrupted';run.completedAt=new Date().toISOString();changed=true;
      for(const item of run.items||[]){if(item.status==='running')item.status='unknown';else if(item.status==='queued')item.status='not_started';}
    }
  }
  return changed;
}

export function validateBackup(data) {
  const fail=()=>{throw new Error('备份格式、字段或关联无效；没有修改当前数据。');};
  if(!data||data.version!==SCHEMA_VERSION||!Array.isArray(data.projects)||!data.projects.length||data.projects.length>50||!id(data.activeProjectId))fail();
  const unique=items=>items.every(x=>x&&id(x.id))&&new Set(items.map(x=>x.id)).size===items.length;
  if(!unique(data.projects)||!data.projects.some(p=>p.id===data.activeProjectId))fail();
  for(const p of data.projects){
    if(!p||typeof p!=='object')fail();
    if(!text(p.name,1,80)||!text(p.appName,1,120)||!Array.isArray(p.topics)||!Array.isArray(p.feedback)||!Array.isArray(p.requirements)||!Array.isArray(p.imports)||p.feedback.length>10000||p.topics.length>500||p.requirements.length>2000||!unique(p.topics)||!unique(p.feedback)||!unique(p.requirements))fail();
    for(const t of p.topics)if(!t||!text(t.name,2,30)||!['confirmed','candidate','archived'].includes(t.status)||(t.revision!==undefined&&(!Number.isInteger(t.revision)||t.revision<0)))fail();
    for(const f of p.feedback){
      if(!f||typeof f!=='object')fail();
      if(!text(f.content,1,5000)||!['pending','confirmed','modified','rejected'].includes(f.review)||!['queued','failed','succeeded'].includes(f.analysisStatus)||!Number.isInteger(f.revision)||f.revision<0||!Array.isArray(f.history)||!Array.isArray(f.keys)||f.keys.some(k=>typeof k!=='string')||!text(f.source||'',0,80)||!text(f.origin||'',0,80))fail();
      if(f.topicId!==null&&!p.topics.some(t=>t.id===f.topicId))fail();
      if(f.analysisStatus==='succeeded'&&(!['positive','negative','neutral','uncertain'].includes(f.sentiment)||!['feature_request','bug','usability','performance','other','uncertain'].includes(f.issueType)||!f.topicId))fail();
      if(f.date!==null&&(typeof f.date!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(f.date)||Number.isNaN(Date.parse(f.date))||new Date(f.date).toISOString().slice(0,10)!==f.date))fail();
    }
    for(const r of p.requirements){
      if(!r||typeof r!=='object')fail();
      if(!text(r.title,1,120)||!text(r.description||'',0,5000)||!['unset','low','medium','high'].includes(r.priority)||!['pending','planned','in_progress','done','rejected'].includes(r.status)||!Number.isInteger(r.revision)||!Array.isArray(r.sources)||!r.sources.length||r.sources.length>200||!Number.isFinite(Date.parse(r.createdAt))||!unique(r.sources))fail();
      for(const s of r.sources)if(!p.feedback.some(f=>f.id===s.id)||!text(s.content,1,5000)||!text(s.topicName,1,30))fail();
    }
    for(const b of p.imports){
      if(!b||!id(b.id)||!text(b.fileName,1,255)||!Number.isFinite(Date.parse(b.createdAt))||['total','imported','invalid','skipped'].some(k=>!Number.isInteger(b[k])||b[k]<0)||b.total!==b.imported+b.invalid+b.skipped)fail();
      if(b.rows!==undefined&&(!Array.isArray(b.rows)||b.rows.length>2000||b.rows.some(r=>!r||!Number.isInteger(r.recordNo)||r.recordNo<2||!['new','duplicate','invalid','empty'].includes(r.outcome)||!Array.isArray(r.errors)||r.errors.some(e=>!text(e,0,500)))))fail();
    }
    if(p.analysisRuns!==undefined){if(!Array.isArray(p.analysisRuns)||p.analysisRuns.length>50)fail();for(const run of p.analysisRuns){if(!id(run.id)||!Array.isArray(run.items)||run.items.length>10||!['running','completed','partial_failed','failed','interrupted','stopped'].includes(run.status)||run.items.some(i=>!id(i.id)||!p.feedback.some(f=>f.id===i.id)||!['queued','running','succeeded','failed','unknown','not_started'].includes(i.status)))fail();}}
  }
  return structuredClone(data);
}

/** Merge a backup as new projects. Existing records are never overwritten. */
export function mergeBackup(current, backup) {
  const clean=validateBackup(backup), next=structuredClone(current);
  if(next.projects.length+clean.projects.length>50)throw new Error('恢复后项目数超过 50 个上限。');
  for(const p of clean.projects){p.id=uid();delete p.seedKey;p.name=[...`${p.name}（恢复）`].slice(0,80).join('');p.isSample=false;next.projects.push(p);}
  next.activeProjectId=clean.projects[0].id;
  return next;
}
