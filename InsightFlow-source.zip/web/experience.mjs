const INTRO_KEY='insightflow-tour-intro-v1';
let recommendationVisible=true;
try{recommendationVisible=localStorage.getItem(INTRO_KEY)!=='seen';if(recommendationVisible)localStorage.setItem(INTRO_KEY,'seen');}catch{/* Keep optional hints usable without browser storage. */}
export function dismissTourRecommendation(){recommendationVisible=false;}
export function tourRecommendation(btn){return recommendationVisible?`<aside class="tour-recommendation" aria-label="首次使用提示"><button type="button" class="recommendation-close" data-action="dismiss-tour-recommendation" aria-label="关闭使用提示">×</button><strong>第一次来？从使用指引开始</strong><p>点击右上角的“使用指引”，用 8 步了解核心操作。可随时关闭，无需跟着完成。</p><div>${btn('start-tour','开始指引','primary')}${btn('dismiss-tour-recommendation','知道了','text')}</div></aside>`:'';}
export function emptyProjectStart(project,btn){if(project.feedback.length)return '';return `<section class="journey-card" aria-label="空项目开始指引"><div class="journey-head"><div><span class="journey-eyebrow">从第一条反馈开始</span><h2>先带进原文，再决定如何整理。</h2></div></div><p>数据保存在当前浏览器。录入或导入不会自动调用 AI；你可以先查看原文，再选择关键词模拟或真实分析。</p><div class="journey-actions">${btn('manual-feedback','手工录入第一条','primary')}${btn('import','导入自己的 CSV','secondary')}${btn('guide-sample-csv','导入合成示例 CSV','secondary')}</div></section>`;}

export function sourceSummary(feedback,esc){
  const synthetic=feedback.filter(f=>f.dataKind==='synthetic'||f.seedId||f.origin==='示例预设').length;
  const actual=feedback.filter(f=>f.origin==='DeepSeek 真实分析').length;
  const mock=feedback.filter(f=>f.origin==='关键词模拟').length;
  const preset=feedback.filter(f=>f.origin==='示例预设').length;
  const other=feedback.length-actual-mock-preset;
  return `<span>数据标识：合成 ${synthetic} 条；导入、录入或尚未核实 ${feedback.length-synthetic} 条。</span><span>分析来源：DeepSeek ${actual} 条 · 关键词模拟 ${mock} 条 · 示例预设 ${preset} 条 · 待处理/其他 ${other} 条。</span><span>${esc('真实模型输出不代表原文来自真实用户；导入数据的真实性需由提供者核实。')}</span>`;
}

export function chartNote(feedback){
  const n=origin=>feedback.filter(f=>f.origin===origin).length;
  return `<p class="chart-scope">当前样本 ${feedback.length} 条有效分类 · DeepSeek ${n('DeepSeek 真实分析')} / 关键词模拟 ${n('关键词模拟')} / 示例预设 ${n('示例预设')}。不代表真实用户数或满意度。</p>`;
}

export function aiOperationStatus(project,backend,selected,esc,btn){
  const items=selected.map(id=>project.feedback.find(f=>f.id===id)).filter(Boolean);
  const max=backend.mode==='cloud'?1:10, longest=Math.max(0,...items.map(f=>[...f.content].length));
  const ready=backend.configured&&['local','cloud'].includes(backend.mode);
  const over=backend.mode==='cloud'&&longest>1500;
  const run=project.analysisRuns?.[0];
  return `<div class="ai-operation-head"><strong>真实 AI：${ready?'已连接并启用':'暂未连接或启用'}</strong>${btn('ai-settings','查看连接与限制','text')}</div><p>已选 <b>${items.length}</b> 条 · 单次最多 ${max} 条${backend.mode==='cloud'?'、每条 1,500 字符':''}。${over?'所选正文超过限制，不会截断发送。':items.length>max?'请减少选择后提交。':'提交前还会展示原文并要求确认。'}</p>${run?`<p>最近一轮：${run.items.filter(i=>i.status==='succeeded').length} 条已保存，${run.items.filter(i=>i.status==='failed').length} 条失败，${run.items.filter(i=>i.status==='unknown').length} 条结果未知。${btn('analysis-history','查看记录与原因','text')}</p>`:''}<details><summary>额度和失败后如何处理</summary><p>${backend.mode==='cloud'?'当前限制：每个 IP 每天 3 次、全站每天 10 次、累计 20 次后暂停；这是次数上限，不是账户余额。剩余名额暂未提供实时查询。':'本地分析也会消耗你的 DeepSeek 额度。'} 连接就绪不表示一定还有额度。失败或超时可能已被供应商处理，也会占体验名额；不会自动重试。先查看记录和原因，结果未知时不要连续重发。</p><p>关键词模拟不调用模型、不代表真实 AI 输出；真实分析发送所选脱敏正文到服务端与 DeepSeek，可能产生费用。${esc('打开页面、筛选和查看结果不会发起真实分析。')}</p></details>`;
}
