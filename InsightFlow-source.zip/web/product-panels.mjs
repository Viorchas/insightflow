import { validateRows } from './domain/csv.js';
import { projectOf, uid } from './demo-model.mjs';
import { REQUIREMENT_FIELDS } from './workspace.mjs';

export function requirementFields(esc,values={}) {
  return `<details><summary>补充决策、验收与验证记录</summary>${REQUIREMENT_FIELDS.map(([k,label,max])=>`<label>${label}${k==='targetVersion'?`<input name="${k}" maxlength="${max}" value="${esc(values[k]||'')}">`:`<textarea name="${k}" rows="2" maxlength="${max}">${esc(values[k]||'')}</textarea>`}</label>`).join('')}<label>效果验证<select name="verificationState">${[['not_checked','尚未验证'],['checked','已记录验证'],['inconclusive','暂不能判断']].map(([k,label])=>`<option value="${k}" ${(values.verificationState||'not_checked')===k?'selected':''}>${label}</option>`).join('')}</select></label><p class="footnote">完成开发与效果验证分别记录；验证内容由你填写，不自动推断业务收益。</p></details>`;
}

export function createProductPanels({getState,commit,openModal,modal,esc,btn,render,toast,formError,go,download}) {
  function manualFeedback(){
    const projectId=projectOf(getState()).id;
    openModal('手工录入反馈',`<form id="manual-feedback"><label>反馈原文<textarea name="content" rows="4" required maxlength="5000" placeholder="粘贴或输入一条有权处理的反馈"></textarea></label><div class="form-grid"><label>来源<input name="source" maxlength="80" placeholder="例如：产品内反馈"></label><label>来源中的记录 ID<input name="external_id" maxlength="200" placeholder="选填；填写后必须有来源"></label><label>平台<input name="platform" maxlength="40" placeholder="例如：Web / iOS"></label><label>App 版本<input name="app_version" maxlength="80" placeholder="例如：1.2.0"></label><label>反馈日期<input name="feedback_at" type="date"></label><label>评分（1—5，可小数）<input name="rating" type="number" min="1" max="5" step="any"></label></div><label class="checkbox-label"><input type="checkbox" name="allowSameContent">若已有相同正文，我确认这是一条独立反馈，仍需保存。</label><p class="footnote">保存后待分析，不自动调用 AI。相同来源 + 记录 ID 不重复保存；相同文字不代表同一个用户。</p><div class="form-actions">${btn('close','取消','secondary')}<button class="btn primary" type="submit">保存反馈</button></div></form>`,true);
    document.querySelector('#manual-feedback').addEventListener('submit',event=>{
      event.preventDefault();
      try{
        const fields=Object.fromEntries(new FormData(event.target)), names=['content','source','external_id','platform','app_version','feedback_at','rating'];
        const result=validateRows({headers:names,rows:[names.map(k=>String(fields[k]||''))]},Object.fromEntries(names.map((k,i)=>[k,i])))[0];
        if(result.status!=='valid')throw new Error(result.errors.join('；')||'请输入反馈正文。');
        const v=result.values;
        commit(p=>{
          if(p.id!==projectId)throw new Error('当前项目已变化，请重新打开录入窗口。');
          if(p.feedback.length>=10000)throw new Error('当前演示项目最多保留 10,000 条反馈，请先备份并整理数据。');
          const key=v.external_id?JSON.stringify(['source',v.source,v.external_id]):null;
          if(key&&p.feedback.some(f=>(f.keys||[]).includes(key)))throw new Error('该来源与记录 ID 已存在，未重复保存。');
          if(!fields.allowSameContent&&p.feedback.some(f=>f.content.trim()===v.content))throw new Error('已有相同正文。若为独立反馈，请勾选确认后再保存。');
          p.feedback.unshift({id:uid(),content:v.content,rawText:v.raw_text,source:v.source||'手工录入',externalId:v.external_id||null,platform:v.platform||'',appVersion:v.app_version||'',date:v.date,feedbackAt:v.feedback_at,rating:v.rating,topicId:null,sentiment:'uncertain',issueType:'uncertain',review:'pending',analysisStatus:'queued',origin:'待分析',revision:0,history:[],keys:key?[key]:[],createdAt:new Date().toISOString()});
        });
        modal.close();go('feedback',{analysis:'queued'});toast('反馈已保存到本机，尚未调用 AI。');
      }catch(error){formError(error);}
    });
  }
  function exportRequirement(id){
    const p=projectOf(getState()),r=p.requirements.find(r=>r.id===id);if(!r)throw new Error('需求不存在。');
    const literal=value=>String(value||'未填写').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const lines=[`# ${literal(r.title)}`, '',`项目：${literal(p.name)}`,`状态：${literal(r.status)}｜人工优先级：${literal(r.priority)}`,'','## 描述',literal(r.description)];
    for(const [key,label] of REQUIREMENT_FIELDS)lines.push('',`## ${label}`,literal(r[key]));
    lines.push('','## 效果验证状态',literal({not_checked:'尚未验证',checked:'已记录验证',inconclusive:'暂不能判断'}[r.verificationState||'not_checked']),'','## 关联来源快照');
    r.sources.forEach((s,i)=>lines.push('',`### 来源 ${i+1}`,`主题：${literal(s.topicName)}｜来源类型：${literal(s.origin)}`,literal(s.content)));
    lines.push('','---','导出自 InsightFlow 当前浏览器数据。示例项目与合成反馈不代表真实调研或业务成绩。');
    download(`insightflow-requirement-${r.id}.md`,lines.join('\n'),'text/markdown;charset=utf-8');
  }
  return {manualFeedback,exportRequirement};
}
