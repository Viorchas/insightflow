const STEPS = [
  { page:'overview', target:'.data-context', fallback:'.journey-card', title:'先认识数据来源', text:'这里分别说明原文来源与分析方式。chatagent 的预置反馈是合成数据，即使经过真实 AI 分析，也不代表真实用户调研。', empty:'当前项目还没有反馈，可以从后面的导入入口开始。' },
  { page:'overview', target:'.analytics-grid .topic-panel', title:'读懂洞察的范围', text:'主题和情绪图表统计有效分类。日期、审核范围和图旁说明决定统计口径；尚未审核的建议需要先核查原文。' },
  { page:'feedback', target:'.page-heading [data-action="import"]', title:'带入自己的反馈', text:'点击“导入反馈”可上传 CSV，经过字段映射、校验和预览后再保存。也可在列表上方手工录入。导入不会自动分析或扣费。' },
  { page:'feedback', target:'#ai-operation-status', title:'分析前先看连接与限制', text:'勾选反馈后，通过“真实 AI 分析”提交；每次都会要求确认，可能消耗作者额度。这里说明连接、提交限制和失败处理。关键词模拟不调用模型。' },
  { page:'feedback', target:'.feedback-content button', fallback:'.table-panel', title:'对照原文做人工审核', text:'点击反馈原文打开详情，核查摘要、主题、情绪和问题类型，再保存审核或拒绝分类。分类只是建议，不能直接当成结论。', empty:'当前项目还没有反馈。导入或录入并完成分类后，就可以在这里核查原文。' },
  { page:'topics', target:'.topic-card', fallback:'.topic-cards', title:'确认主题再形成判断', text:'主题把相似反馈组织在一起。候选主题需要人工确认；主题卡片可查看关联反馈、管理主题，并从来源创建需求。', empty:'当前项目还没有主题。完成分类后，主题会在这里呈现。' },
  { page:'requirements', target:'.page-heading [data-action="new-requirement"]', title:'把反馈变成有来源的需求', text:'创建需求会先引导你去反馈列表选择来源。保留原文快照，再记录问题、优先级与处理状态；决策理由、验收和效果验证可以逐步补充。' },
  { page:'requirements', target:'.top-actions [data-action="restore-backup"]', title:'记得备份本机数据', text:'数据仅保存在当前浏览器，清理站点数据会丢失。通过“演示说明”导出 JSON 备份，再通过这里校验并恢复。指引结束后会回到你开始时的页面。' },
];

export function createGuidedTour({ navigate, capture, restore, canStart, getProject }) {
  let active=false, index=0, saved=null, dialog=null, frame=0, anchor=null;
  const shades=[];
  let ring, card, observer;
  const clamp=(v,min,max)=>Math.min(Math.max(v,min),Math.max(min,max));

  function position() {
    frame=0;
    if(!active||!dialog?.open)return;
    const width=document.documentElement.clientWidth, height=window.innerHeight, gap=12;
    const step=STEPS[index];
    anchor=document.querySelector(step.target)||document.querySelector(step.fallback||step.target);
    const rect=anchor?.getBoundingClientRect();
    const visible=rect&&rect.width>0&&rect.height>0&&rect.bottom>0&&rect.top<height;
    const box=visible?{left:clamp(rect.left-5,4,width-4),top:clamp(rect.top-5,4,height-4),right:clamp(rect.right+5,4,width-4),bottom:clamp(rect.bottom+5,4,height-4)}:null;
    const sizes=box?[
      [0,0,width,box.top],[0,box.bottom,width,height-box.bottom],
      [0,box.top,box.left,box.bottom-box.top],[box.right,box.top,width-box.right,box.bottom-box.top],
    ]:[[0,0,width,height],[0,0,0,0],[0,0,0,0],[0,0,0,0]];
    sizes.forEach(([x,y,w,h],i)=>Object.assign(shades[i].style,{left:`${x}px`,top:`${y}px`,width:`${w}px`,height:`${h}px`}));
    ring.hidden=!box;
    if(box)Object.assign(ring.style,{left:`${box.left}px`,top:`${box.top}px`,width:`${box.right-box.left}px`,height:`${box.bottom-box.top}px`});
    const cw=card.offsetWidth,ch=card.offsetHeight;
    let left=(width-cw)/2,top=(height-ch)/2;
    if(box){
      left=clamp(box.left,gap,width-cw-gap);
      if(height-box.bottom>=ch+gap*2)top=box.bottom+gap;
      else if(box.top>=ch+gap*2)top=box.top-ch-gap;
      else if(width-box.right>=cw+gap*2){left=box.right+gap;top=clamp(box.top,gap,height-ch-gap);}
      else if(box.left>=cw+gap*2){left=box.left-cw-gap;top=clamp(box.top,gap,height-ch-gap);}
      else top=height-ch-gap;
    }
    Object.assign(card.style,{left:`${clamp(left,gap,width-cw-gap)}px`,top:`${clamp(top,gap,height-ch-gap)}px`});
  }
  function refresh(){if(active&&saved&&getProject().id!==saved.projectId){stop();return;}if(active&&!frame)frame=requestAnimationFrame(position);}

  function show(next) {
    index=next;
    const step=STEPS[index];
    navigate(step.page);
    const empty=getProject().feedback.length===0;
    card.querySelector('#tour-title').textContent=step.title;
    card.querySelector('#tour-description').textContent=empty&&step.empty?step.empty:step.text;
    card.querySelector('.tour-progress').textContent=`使用指引 · ${index+1} / ${STEPS.length}`;
    card.querySelector('[data-tour="previous"]').disabled=index===0;
    card.querySelector('[data-tour="next"]').textContent=index===STEPS.length-1?'完成指引':'下一步';
    anchor=document.querySelector(step.target)||document.querySelector(step.fallback||step.target);
    anchor?.scrollIntoView({block:'start',inline:'nearest',behavior:'instant'});
    if(anchor)window.scrollBy({top:-24,behavior:'instant'});
    refresh();
    card.querySelector('[data-tour="next"]').focus({preventScroll:true});
  }

  function stop() {
    if(!active)return;
    active=false;
    cancelAnimationFrame(frame);frame=0;
    observer?.disconnect();
    window.removeEventListener('hashchange',stop);
    window.removeEventListener('resize',refresh);
    window.removeEventListener('scroll',refresh,true);
    dialog.close();dialog.remove();dialog=null;
    restore(saved);saved=null;
  }

  function start() {
    if(active)return;
    if(!canStart())return;
    saved=capture();active=true;
    dialog=document.createElement('dialog');
    dialog.className='guided-tour';
    dialog.setAttribute('aria-labelledby','tour-title');
    dialog.setAttribute('aria-describedby','tour-description');
    shades.length=0;
    for(let i=0;i<4;i++){const shade=document.createElement('div');shade.className='tour-shade';shade.setAttribute('aria-hidden','true');dialog.append(shade);shades.push(shade);}
    ring=document.createElement('div');ring.className='tour-highlight';ring.setAttribute('aria-hidden','true');dialog.append(ring);
    card=document.createElement('section');card.className='tour-card';
    card.innerHTML='<div class="tour-heading"><span class="tour-progress"></span><button type="button" class="tour-close" data-tour="close" aria-label="关闭使用指引">关闭 ×</button></div><h2 id="tour-title"></h2><p id="tour-description"></p><p class="tour-note">仅介绍操作，不会导入、审核或发起 AI 请求。随时按 Esc 退出。</p><div class="tour-actions"><button type="button" class="btn secondary" data-tour="previous">上一步</button><button type="button" class="btn primary" data-tour="next">下一步</button></div>';
    dialog.append(card);document.body.append(dialog);
    dialog.addEventListener('click',event=>{const action=event.target.closest('[data-tour]')?.dataset.tour;if(action==='close')stop();else if(action==='previous'&&index>0)show(index-1);else if(action==='next'){if(index===STEPS.length-1)stop();else show(index+1);}});
    dialog.addEventListener('cancel',event=>{event.preventDefault();stop();});
    dialog.addEventListener('keydown',event=>{if(event.key==='ArrowRight'){event.preventDefault();if(index<STEPS.length-1)show(index+1);}else if(event.key==='ArrowLeft'){event.preventDefault();if(index>0)show(index-1);}});
    dialog.showModal();
    window.addEventListener('hashchange',stop);
    window.addEventListener('resize',refresh);
    window.addEventListener('scroll',refresh,true);
    observer=new ResizeObserver(refresh);observer.observe(document.querySelector('#app'));observer.observe(card);
    show(0);
  }
  return {start,stop,refresh};
}
