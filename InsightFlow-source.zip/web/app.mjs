import { parseCsv, validateRows, escapeCsvCell } from './domain/csv.js';
import { assertTransition, normalizeTopicName } from './domain/workflow.js';
import { initialState, projectOf, effective, isReviewed, classifyMock, reviewFeedback, createRequirement, saveState, loadState, uid, STORAGE_KEY } from './demo-model.mjs';
import { setTopicStatus, matchesFeedback, recoverInterruptedRuns } from './workspace.mjs';
import { createPanels } from './panels.mjs';
import { createProductPanels, requirementFields } from './product-panels.mjs';
import { REQUIREMENT_FIELDS, requirementExtras } from './workspace.mjs';
import { CLOUD_API_BASE } from './cloud-config.mjs';

const $ = (s, root = document) => root.querySelector(s);
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const localDate = iso => new Intl.DateTimeFormat('sv-SE', { timeZone: 'Asia/Hong_Kong', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(iso));
const icons = {
  grid: '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
  chat: '<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5H4l-1 1V11.5A8.5 8.5 0 0 1 11.5 3h1a8.5 8.5 0 0 1 8.5 8.5Z"/><path d="M7 9h10M7 13h6"/>',
  layers: '<path d="m12 3 10 5-10 5L2 8l10-5Zm-9 10 9 5 9-5M3 18l9 5 9-5"/>',
  list: '<rect x="4" y="3" width="16" height="18" rx="3"/><path d="M8 8h8M8 12h8M8 16h4"/>',
  arrow: '<path d="M5 12h14m-6-6 6 6-6 6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  upload: '<path d="M12 16V3m-5 5 5-5 5 5M4 15v5h16v-5"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  search: '<circle cx="10" cy="10" r="6"/><path d="m15 15 5 5"/>',
  spark: '<path d="m12 3 2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5L12 3Z"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
};
const icon = (name, extra = '') => `<svg class="icon ${extra}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name] || icons.grid}</svg>`;
const labels = { pending: '待审核', confirmed: '已确认', modified: '已修正', rejected: '已拒绝', positive: '正向', negative: '负向', neutral: '中性', uncertain: '不确定', feature_request: '功能请求', bug: '缺陷', usability: '使用体验', performance: '性能', other: '其他', unset: '未设置', low: '低', medium: '中', high: '高', planned: '已规划', in_progress: '进行中', done: '已完成' };
const reqLabels = { ...labels, pending: '待评估' };
let state, storageError = '', storageCorrupt = false;
try { state = loadState(localStorage); recoverInterruptedRuns(state); saveState(localStorage, state); }
catch (e) { state = initialState(); storageError = e.message; storageCorrupt = true; }
let selected = new Set(), page = 1, importData = null, formDirty = false;
let backend = { mode: 'static', configured: false, model: 'deepseek-flash', csrfToken: '' };
let realAiRun = null;
const apiBase = ['localhost','127.0.0.1'].includes(location.hostname) ? '.' : CLOUD_API_BASE;
const modal = $('#modal');
const panels=createPanels({getState:()=>state,setState:value=>{state=value;storageCorrupt=false;storageError='';selected.clear();},commit,openModal,modal,esc,btn,tag,render,toast,formError,isBusy:()=>Boolean(realAiRun?.confirmed)});

const products=createProductPanels({getState:()=>state,commit,openModal,modal,esc,btn,render,toast,formError,go,download});

async function refreshBackend() {
  try {
    const response = await fetch(`${apiBase}/api/v1/config`, { signal: AbortSignal.timeout(8000), cache: 'no-store', credentials:'omit' });
    if (!response.ok) throw new Error('unavailable');
    const body = await response.json();
    if (!['local','cloud'].includes(body.data?.mode) || typeof body.data.csrfToken !== 'string') throw new Error('unsupported');
    backend = body.data;
  } catch { backend = { mode: 'static', configured: false, model: 'deepseek-flash', csrfToken: '' }; }
}

function aiSettings() {
  const local = backend.mode === 'local', cloud = backend.mode === 'cloud';
  openModal('真实 AI 连接状态', `<div class="detail-meta">${tag(local ? '本地后台已连接' : cloud ? '云端接口已连接' : '暂未连接 AI 接口',(local||cloud)?'green':'amber')}${tag(backend.configured?'真实 AI 已启用':'真实 AI 暂未启用',backend.configured?'green':'amber')}</div><p>供应商：DeepSeek · 模型：${esc(backend.model)}</p><p>${local ? '本地服务使用 .env 中的密钥；页面只读取启用状态，不读取或展示密钥。' : cloud ? '真实分析由云端接口转发，密钥只保存在服务端。每次 1 条、最多 1,500 字符；每个访问地址每天 3 次，全站每天 10 次，累计 20 次后暂停。失败和超时可能消耗体验次数，不自动重试。' : '暂时无法连接真实 AI 接口。已有数据和明确标记的模拟分析仍可使用，真实分析不会静默降级。'}</p><div class="notice-inline">免费指网页和接口托管。真实分析会将脱敏后的所选反馈发送至服务端和 DeepSeek，并消耗作者的 API 额度；发送前需确认。</div><div class="form-actions">${btn('refresh-ai','重新检查连接','secondary')}${btn('close','知道了','primary')}</div>`);
}

function startRealAi() {
  if (realAiRun) return toast('已有真实分析正在进行，请等待或停止后续请求。');
  if (!backend.configured || !['local','cloud'].includes(backend.mode)) return aiSettings();
  const p=projectOf(state), ids=[...selected];
  const maxBatch=backend.mode==='cloud'?1:10;
  if (!ids.length || ids.length>maxBatch) throw new Error(`请先选择 1—${maxBatch} 条待审核反馈。`);
  const fs=ids.map(id=>p.feedback.find(f=>f.id===id));
  if (fs.some(f=>!f||f.review!=='pending')) throw new Error('只允许分析待审核反馈，人工确认、修改或拒绝的结果不会被覆盖。');
  if(backend.mode==='cloud' && (fs.some(f=>[...f.content].length>1500)||p.topics.filter(t=>t.status==='confirmed').length>30))throw new Error('公开真实 AI 体验仅支持不超过 1,500 字符的反馈和最多 30 个已确认主题，原文不会被截断。');
  openModal('确认发送至 DeepSeek',`<p>将分析 ${fs.length} 条反馈，使用 ${esc(backend.model)}。邮箱和手机号会做基础脱敏，但不能保证识别全部个人信息，请确认有权处理这些内容。</p><p>每条发送一次请求，本轮不自动付费重试。失败条目保留原因，可由你明确选择后重试。</p><div class="source-list">${fs.map(f=>`<div><p>${esc(f.content)}</p></div>`).join('')}</div><div class="form-actions">${btn('close','取消','secondary')}${btn('confirm-real-ai','确认发送并分析','primary')}</div>`);
  realAiRun={projectId:p.id, items:fs.map(f=>({id:f.id,revision:f.revision,content:f.content})),confirmed:false,stop:false,done:0,failed:0};
}

async function runRealAi() {
  const run=realAiRun;
  if(!run || run.confirmed)return;
  run.journalId=uid();
  try {commit((_p,s)=>{const p=s.projects.find(p=>p.id===run.projectId);p.analysisRuns||=[];p.analysisRuns.unshift({id:run.journalId,createdAt:new Date().toISOString(),status:'running',items:run.items.map(i=>({id:i.id,status:'queued'}))});p.analysisRuns=p.analysisRuns.slice(0,50);});}catch(e){realAiRun=null;throw e;}
  run.confirmed=true;
  openModal('DeepSeek 分析中',`<p id="real-progress" role="status">准备发送 ${run.items.length} 条反馈…</p><p>可以关闭窗口。页面关闭或刷新会中断本轮处理，尚未提交的结果不会保存。已成功结果仍保留。</p><div class="form-actions">${btn('stop-real-ai','停止后续请求','secondary')}${btn('close','关闭窗口','text')}</div>`);
  try {
    for (const item of run.items) {
      if(run.stop)break;
      const project=state.projects.find(p=>p.id===run.projectId), f=project?.feedback.find(f=>f.id===item.id);
      if(!f || f.revision!==item.revision || f.review!=='pending'){run.failed++;commit((_p,s)=>{s.projects.find(p=>p.id===run.projectId).analysisRuns.find(r=>r.id===run.journalId).items.find(i=>i.id===item.id).status='not_started';});continue;}
      const topics=project.topics.filter(t=>t.status==='confirmed').map(t=>({id:t.id,name:t.name}));
      try {
        commit((_p,s)=>{const log=s.projects.find(p=>p.id===run.projectId).analysisRuns.find(r=>r.id===run.journalId);log.updatedAt=new Date().toISOString();log.items.find(i=>i.id===item.id).status='running';});
        const response=await fetch(`${apiBase}/api/v1/analyze`,{method:'POST',credentials:'omit',headers:{'Content-Type':'application/json','x-insightflow-token':backend.csrfToken},body:JSON.stringify({content:item.content,topics,requestId:uid()}),signal:AbortSignal.timeout(50_000)});
        const body=await response.json();
        if(!response.ok){const error=new Error(body.error?.message||'分析请求失败');error.code=body.error?.code;throw error;}
        const result=body.data;
        commit((_p,s)=>{
          const p=s.projects.find(p=>p.id===run.projectId), current=p?.feedback.find(f=>f.id===item.id);
          if(!current || current.revision!==item.revision || current.review!=='pending')throw new Error('反馈已发生变化，未覆盖当前结果。');
          const output=result.output;
          let topic=p.topics.find(t=>t.id===output.topic_id&&t.status==='confirmed');
          if(!topic && output.proposed_topic_name){topic=p.topics.find(t=>normalizeTopicName(t.name)===normalizeTopicName(output.proposed_topic_name));if(!topic){topic={id:uid(),name:output.proposed_topic_name,status:'candidate',description:'DeepSeek 提出的候选主题，待人工确认。'};p.topics.push(topic);}}
          if(!topic||topic.status==='archived')throw new Error('主题库已变化或主题已归档，请恢复主题后重新分析。');
          current.aiVersions ||= [];
          current.aiVersions.push({output,metadata:result.metadata,createdAt:new Date().toISOString()});
          Object.assign(current,{topicId:topic.id,sentiment:output.sentiment,issueType:output.issue_type,summary:output.summary,evidenceQuote:output.evidence_quote,reviewReasons:output.review_reasons,origin:'DeepSeek 真实分析',analysisStatus:'succeeded',revision:current.revision+1,lastAiError:null});
          p.analysisRuns.find(r=>r.id===run.journalId).items.find(i=>i.id===item.id).status='succeeded';
        });
        run.done++;
      } catch(error) {
        run.failed++;
        const message=error.name==='TimeoutError'?'请求超时；本地未保存结果，供应商可能已处理。重试可能再次消耗额度。':error.message;
        try {commit((_p,s)=>{const p=s.projects.find(p=>p.id===run.projectId);const log=p.analysisRuns.find(r=>r.id===run.journalId).items.find(i=>i.id===item.id);log.status='failed';log.error=message;const f=p.feedback.find(f=>f.id===item.id);if(f&&f.revision===item.revision){f.lastAiError=message;if(f.analysisStatus!=='succeeded')f.analysisStatus='failed';}});} catch(storageFailure){run.stop=true;toast(storageFailure.message);}
        if(['AI_AUTH_ERROR','AI_NOT_CONFIGURED','INVALID_SESSION','AI_RATE_LIMITED','LOCAL_RATE_LIMIT','DEMO_QUOTA_LIMIT'].includes(error.code))run.stop=true;
      }
      const progress=$('#real-progress');if(progress)progress.textContent=`成功 ${run.done} 条 · 失败 ${run.failed} 条 · 总计 ${run.items.length} 条`;
      render();
    }
    commit((_p,s)=>{const log=s.projects.find(p=>p.id===run.projectId).analysisRuns.find(r=>r.id===run.journalId);log.status=run.stop?'stopped':run.failed?(run.done?'partial_failed':'failed'):'completed';log.completedAt=new Date().toISOString();for(const i of log.items)if(i.status==='queued')i.status='not_started';});
    const text=`真实分析${run.stop?'已停止':'结束'}：成功 ${run.done} 条，失败 ${run.failed} 条，未处理 ${run.items.length-run.done-run.failed} 条。`;
    const progress=$('#real-progress');if(progress)progress.textContent=text;
    toast(text);
  } finally {realAiRun=null;selected.clear();render();}
}

function commit(fn) {
  if (storageCorrupt) throw new Error('本地存储不可用或数据损坏，请先导出备份并重置演示。');
  const candidate = structuredClone(state);
  fn(projectOf(candidate), candidate);
  saveState(localStorage, candidate);
  state = candidate;
}
function toast(message) { $('#toast').textContent = message; $('#toast').classList.add('show'); clearTimeout(toast.timer); toast.timer = setTimeout(() => $('#toast').classList.remove('show'), 4000); }
function route() {
  const hash = location.hash.slice(1) || 'overview';
  const [name, query = ''] = hash.split('?');
  return { name: ['overview', 'feedback', 'topics', 'requirements'].includes(name) ? name : 'overview', params: new URLSearchParams(query) };
}
function go(name, filters = {}) { selected.clear(); page = 1; const query = new URLSearchParams(filters).toString(); location.hash = `${name}${query ? '?' + query : ''}`; if (route().name === name) render(); }
function filtered(params = route().params) {
  return projectOf(state).feedback.filter(f => matchesFeedback(f,params));
}
function dateFilters(params) {return `<div class="date-filters"><label>反馈日期从<input type="date" data-filter="from" aria-label="起始日期" value="${esc(params.get('from')||'')}"></label><label>至<input type="date" data-filter="to" aria-label="结束日期" value="${esc(params.get('to')||'')}"></label><span>按香港时区；指定范围后不计时间未知记录</span></div>`;}
function empty(title, detail, button = '') { return `<div class="empty">${icon('layers')}<h3>${title}</h3><p>${detail}</p>${button}</div>`; }
function btn(action, text, style = 'secondary', extra = '') { return `<button type="button" class="btn ${style}" data-action="${action}" ${extra}>${text}</button>`; }
function tag(text, style = '') { return `<span class="tag ${style}">${esc(text)}</span>`; }
function topicOf(p, f) { return p.topics.find(t => t.id === f.topicId); }
function reviewTag(f) { return tag(labels[f.review], f.review === 'pending' ? 'amber' : isReviewed(f) ? 'green' : 'muted'); }

function render() {
  const p = projectOf(state), { name, params } = route();
  const nav = [['overview', 'grid', '洞察概览'], ['feedback', 'chat', '用户反馈'], ['topics', 'layers', '主题洞察'], ['requirements', 'list', '需求管理']];
  const pending = p.feedback.filter(f => f.review === 'pending').length;
  $('#app').innerHTML = `<aside class="sidebar"><a class="brand" href="#overview"><img src="./favicon.svg" width="34" height="34" alt="">InsightFlow<span>↗</span></a>
    <div class="workspace-label">当前项目 <span>PROJECT</span></div><label class="project-select"><span class="project-icon">${esc(p.name[0])}</span><select id="project-select" aria-label="切换项目">${state.projects.map(x => `<option value="${x.id}" ${x.id === p.id ? 'selected' : ''}>${esc(x.name)}</option>`).join('')}</select>${icon('down')}</label>
    <nav>${nav.map(([key, ico, title]) => `<a href="#${key}" class="nav-item ${name === key ? 'active' : ''}">${icon(ico)}${title}${key === 'feedback' ? `<small>${p.feedback.length}</small>` : key === 'requirements' ? `<small>${p.requirements.length}</small>` : ''}</a>`).join('')}</nav>
    <button class="new-project" data-action="new-project">${icon('plus')} 创建新项目</button>
    <div class="sidebar-bottom"><div class="demo-card"><span class="live-dot"></span> 公开交互演示<p>示例数据 · 本机保存<br>${backend.configured ? '真实分析需确认 · 可能计费' : '真实 AI 暂未连接或启用'}</p>${btn('about', '了解演示模式 '+icon('arrow'), 'text')}</div><div class="profile"><span class="avatar">访</span><div>访客体验<small>无需注册，即刻探索</small></div></div></div></aside>
    <div class="main"><header class="topbar"><div><span class="breadcrumb">工作台</span><span class="slash">/</span><strong>${nav.find(n => n[0] === name)[2]}</strong></div><div class="top-actions"><span class="local-note"><i></i>仅存当前浏览器</span>${btn('ai-settings', backend.configured ? 'AI 已就绪' : 'AI 配置', 'text')}${btn('restore-backup', '恢复备份', 'text')}${btn('about', '演示说明', 'text')}</div></header>
    <div class="content">${storageError ? `<div class="alert">${esc(storageError)} ${btn('backup', '导出原始备份', 'text')} ${btn('reset', '重置演示', 'text')}</div>` : ''}
    <div class="page-heading"><div><div class="eyebrow">${esc(p.appName)} <span> / </span> FEEDBACK WORKSPACE</div><h1>${{ overview: '让反馈，成为下一步。', feedback: '每条反馈，都有迹可循。', topics: '从零散声音，到共性问题。', requirements: '让洞察，走向行动。' }[name]}</h1><p>${{ overview: '发现用户关注的问题，从原文证据出发，做出有依据的产品判断。', feedback: '阅读原文、核查分析建议，将有价值的反馈关联到需求。', topics: '查看相似反馈的聚合结果，确认主题后再用于产品决策。', requirements: '记录产品判断，保留来源证据，持续跟进处理状态。' }[name]}</p></div>${name === 'requirements' ? btn('new-requirement', icon('plus')+'创建需求', 'primary') : btn('import', icon('upload')+'导入反馈', 'primary')}</div>
    ${name === 'overview' ? overview(p, pending, params) : name === 'feedback' ? feedbackPage(p, params) : name === 'topics' ? topicsPage(p) : requirementsPage(p)}
    <footer><span>InsightFlow <b>·</b> 从用户声音，到产品行动</span><button data-action="reset" class="link">重置演示数据</button></footer></div></div>`;
  $('#project-select').addEventListener('change', e => attempt(() => { commit((_p, s) => { s.activeProjectId = e.target.value; }); go('overview'); }));
  const search = $('#search');
  if (search) search.addEventListener('change', () => updateFilter('q', search.value));
  document.querySelectorAll('[data-filter]').forEach(el => el.addEventListener('change', () => updateFilter(el.dataset.filter, el.value)));
  document.querySelectorAll('[data-select]').forEach(el => el.addEventListener('change', () => { el.checked ? selected.add(el.dataset.select) : selected.delete(el.dataset.select); $('#selected-count').textContent = selected.size; }));
}

function overview(p, pending, params) {
  const original=p;
  p={...p,feedback:p.feedback.filter(f=>matchesFeedback(f,{from:params.get('from'),to:params.get('to')}))};
  pending=p.feedback.filter(f=>f.review==='pending').length;
  const reviewedOnly = params.get('scope') === 'reviewed';
  const valid = p.feedback.filter(f => effective(f) && (!reviewedOnly || isReviewed(f)));
  const reviewed = p.feedback.filter(isReviewed).length;
  const ranked = p.topics.map(t => ({ ...t, count: valid.filter(f => f.topicId === t.id).length })).filter(t => t.count).sort((a,b) => b.count-a.count);
  const negative = valid.filter(f => f.sentiment === 'negative').length;
  const portions = ['negative','neutral','positive','uncertain'].map(key=>valid.length ? valid.filter(f=>f.sentiment===key).length/valid.length*100 : 0);
  const edge1=portions[0], edge2=edge1+portions[1], edge3=edge2+portions[2];
  const stats = [[p.feedback.length, '用户反馈', '当前项目的有效导入记录', 'chat'], [ranked.length, '反馈主题', `${p.topics.filter(t => t.status === 'candidate').length} 个候选主题待确认`, 'layers'], [pending, '待审核反馈', 'AI 建议需要你的判断', 'spark'], [p.requirements.length, '已创建需求', '每个需求均保留来源', 'list']];
  const max = Math.max(1, ...ranked.map(t => t.count));
  const dateValues = [...new Set(p.feedback.map(f => f.date).filter(Boolean))].sort().slice(-9);
  const values = dateValues.map(d => valid.filter(f => f.date === d).length), vmax = Math.max(1, ...values);
  return `<div class="demo-banner"><span class="banner-symbol">${icon('spark')}</span><div><strong>先探索，再做判断。</strong> 当前展示${p.isSample ? '虚构 App 的合成反馈；预设、模拟和真实分析会分别标记' : '当前浏览器内的反馈与模拟分析'}，不代表真实用户或业务成绩。</div>${btn('about', '查看说明 '+icon('arrow'), 'text')}</div>${dateFilters(params)}${params.get('from')||params.get('to')?`<p class="footnote">已按日期排除 ${original.feedback.filter(f=>!f.date).length} 条时间未知反馈。${btn('clear-filters','清除筛选','text')}</p>`:''}
    <div class="stats">${stats.map(([value,title,note,ico]) => `<section class="stat"><div class="stat-label">${title}${icon(ico)}</div><strong>${value}<span>${title === '用户反馈' || title === '待审核反馈' ? '条' : '个'}</span></strong><small>${note}</small></section>`).join('')}</div>
    <div class="section-toolbar"><div class="section-title">反馈洞察 <span>INSIGHTS</span></div><div class="segmented"><button class="${!reviewedOnly ? 'selected' : ''}" data-action="scope-all">全部有效结果</button><button class="${reviewedOnly ? 'selected' : ''}" data-action="scope-reviewed">仅已审核</button></div></div>
    <div class="analytics-grid"><section class="panel topic-panel"><div class="panel-head"><div><h2>用户最关心什么</h2><p>按主主题汇总 · ${valid.length} 条有效分类 · 前 5 项</p></div><button class="link" data-action="nav-topics">全部主题 ${icon('arrow')}</button></div>${ranked.length ? `<div class="topic-bars">${ranked.slice(0,5).map((t,i) => `<button class="topic-bar-row" data-action="topic-feedback" data-id="${t.id}"><span class="rank">0${i+1}</span><div class="bar-body"><div class="bar-title"><span>${esc(t.name)} ${t.status === 'candidate' ? '<em>候选</em>' : ''}</span><strong>${t.count} <small>条</small><b>${Math.round(t.count/valid.length*100)}%</b></strong></div><div class="bar-track"><i style="width:${t.count/max*100}%;--bar:${['#b3d8bf','#b9c8f5','#e9c7a4','#cbd1d8'][i%4]}"></i></div></div></button>`).join('')}</div>` : empty('还没有可统计的主题', '导入反馈或切换统计口径后查看。')}</section>
    <section class="panel sentiment-panel"><div class="panel-head"><div><h2>用户情绪</h2><p>分类建议，不等同于满意度</p></div>${icon('chat')}</div><div class="sentiment-body"><div class="donut" style="background:conic-gradient(#e6b6a0 0 ${edge1}%,#e5e9e8 ${edge1}% ${edge2}%,#aacaaf ${edge2}% ${edge3}%,#c2c8d8 ${edge3}% 100%)"><div><strong>${valid.length ? Math.round(negative/valid.length*100)+'%' : '—'}</strong><span>负向反馈占比</span></div></div><div class="legend">${[['negative','负向','#e6b6a0'],['neutral','中性','#e5e9e8'],['positive','正向','#aacaaf'],['uncertain','不确定','#c2c8d8']].map(([key,label,color]) => `<span><i style="background:${color}"></i>${label}<b>${valid.filter(f => f.sentiment === key).length}</b></span>`).join('')}</div></div></section></div>
    <div class="bottom-grid"><section class="panel"><div class="panel-head"><div><h2>反馈时间分布</h2><p>按反馈发生日期 · 不是导入时间</p></div><span class="subtle">${p.feedback.filter(f => !f.date).length} 条时间未知</span></div>${dateValues.length ? `<div class="histogram">${dateValues.map((d,i) => `<div class="hist-col"><span>${values[i]}</span><div class="hist-track"><i style="height:${values[i]/vmax*100}%"></i></div><small>${esc(d.slice(5))}</small></div>`).join('')}</div>` : empty('暂无日期数据', '未知日期的反馈仍计入总量。')}</section>
    <section class="panel next-step"><div class="panel-head"><div><h2>下一步，听清用户。</h2><p>从反馈到需求的工作流</p></div>${icon('arrow')}</div><div class="steps"><div><b class="step-done">${icon('check')}</b><span>导入用户反馈<small>${p.feedback.length} 条反馈已在工作区</small></span></div><div><b>02</b><span>审核主题与分类<small>已审核 ${reviewed}/${p.feedback.length} · 覆盖率 ${p.feedback.length ? Math.round(reviewed/p.feedback.length*100)+'%' : '—'}</small></span></div><div><b>03</b><span>形成可追溯的需求<small>用原文证据支撑每个判断</small></span></div></div>${btn('review-pending', '开始审核 '+icon('arrow'), 'secondary wide')}</section></div>`;
}

function feedbackPage(p, params) {
  const fieldFilters=[['source','来源'],['platform','平台'],['appVersion','App 版本']].map(([key,label])=>{const values=[...new Set(p.feedback.map(f=>f[key]).filter(Boolean))].sort();const chosen=params.get(key);if(chosen&&!values.includes(chosen))values.unshift(chosen);return `<label>${label}<select data-filter="${key}" aria-label="${label}筛选"><option value="">全部${label}</option>${values.map(value=>`<option value="${esc(value)}" ${chosen===value?'selected':''}>${esc(value)}</option>`).join('')}</select></label>`;}).join('');
  const all = filtered(params), pages = Math.max(1, Math.ceil(all.length/20)); page = Math.min(page, pages);
  const visible = all.slice((page-1)*20, page*20);
  return `${p.feedback.some(f=>f.analysisStatus==='queued')?`<div class="notice-inline">还有反馈未分类；导入结果已保存，分类不会自动完成。${btn('simulate','运行本地关键词模拟','text')}</div>`:''}<div class="filterbar"><label class="search">${icon('search')}<input id="search" type="search" placeholder="搜索反馈原文，按 Enter 筛选" value="${esc(params.get('q') || '')}"></label><select data-filter="topic" aria-label="主题筛选"><option value="">全部主题</option>${p.topics.map(t=>`<option value="${t.id}" ${params.get('topic')===t.id?'selected':''}>${esc(t.name)}</option>`).join('')}</select><select data-filter="review" aria-label="审核状态"><option value="">全部审核状态</option>${['pending','confirmed','modified','rejected'].map(s=>`<option value="${s}" ${params.get('review')===s?'selected':''}>${labels[s]}</option>`).join('')}</select>${btn('clear-filters','清除筛选','text')}</div>
    <div class="filterbar">${fieldFilters}${btn('manual-feedback','手工录入反馈','secondary')}${btn('export-feedback','导出当前筛选 CSV','text')}</div>${dateFilters(params)}<div class="filterbar"><label>处理状态 <select data-filter="analysis" aria-label="分析状态"><option value="">全部分析状态</option>${[['queued','待处理'],['succeeded','分析成功'],['failed','分析失败']].map(([v,l])=>`<option value="${v}" ${params.get('analysis')===v?'selected':''}>${l}</option>`).join('')}</select></label>${btn('import-history','查看导入历史','text')}${btn('analysis-history','真实分析记录','text')}</div><div class="selection-bar"><span>共 ${all.length} 条反馈 · 已选 <b id="selected-count">${selected.size}</b> 条</span><div>${btn('select-visible','选择本页','text')}${btn('batch-confirm','批量确认','secondary')}${btn('selected-requirement','转为需求','secondary')}${btn('real-ai','真实 AI 分析','primary')}</div></div>
    <section class="panel table-panel">${visible.length ? `<div class="table-scroll"><table><thead><tr><th class="check-cell"></th><th>用户反馈</th><th>主主题 / 情绪</th><th>审核状态</th><th></th></tr></thead><tbody>${visible.map(f=>`<tr><td><input type="checkbox" aria-label="选择反馈：${esc(f.content.slice(0,16))}" data-select="${f.id}" ${selected.has(f.id)?'checked':''}></td><td class="feedback-content"><button data-action="detail" data-id="${f.id}">${esc(f.content)}</button><small>${esc(f.source)} <span>·</span> ${esc(f.platform || '平台未知')} <span>·</span> ${esc(f.date || '时间未知')} <span>·</span> ${esc(f.origin)}</small>${f.lastAiError ? `<small class="form-error">最近分析失败：${esc(f.lastAiError)}</small>` : ''}</td><td>${effective(f) ? `<span>${esc(topicOf(p,f)?.name || '未归类')}</span><div>${tag(labels[f.sentiment],f.sentiment)}</div>` : '<span class="subtle">无有效分类</span>'}</td><td>${reviewTag(f)}</td><td><button class="icon-btn" aria-label="查看反馈详情" data-action="detail" data-id="${f.id}">${icon('arrow')}</button></td></tr>`).join('')}</tbody></table></div>` : empty('没有匹配的反馈', '尝试清除筛选，或导入一份新的 CSV。', btn('clear-filters','清除筛选'))}<div class="pagination"><span>第 ${page} / ${pages} 页</span><div>${btn('prev-page','上一页','secondary',page===1?'disabled':'')}${btn('next-page','下一页','secondary',page===pages?'disabled':'')}</div></div></section><p class="footnote">模拟分类和示例预设均需人工核查；已拒绝的结果不会重新作为有效分类展示。</p>`;
}

function topicsPage(p) {
  return `<div class="notice-inline">${icon('spark')} 主题是反馈的整理建议。候选主题需人工确认；归档保留历史关联，但不再参与新分类。</div><div class="topic-cards">${p.topics.length ? p.topics.map((t,i)=>{const fs=p.feedback.filter(f=>f.topicId===t.id&&effective(f));return `<section class="panel topic-card"><div class="topic-card-top"><span class="topic-mark color-${i%4}">${icon('layers')}</span>${tag({candidate:'候选主题',confirmed:'已确认主题',archived:'已归档'}[t.status],t.status==='candidate'?'amber':t.status==='confirmed'?'green':'muted')}</div><h2>${esc(t.name)}</h2><p>${esc(t.description||'来自导入反馈的分类主题，请核查原文。')}</p><div class="topic-number">${fs.length}<small>条关联反馈</small></div><blockquote>${esc(fs[0]?.content||'当前没有有效分类的反馈')}</blockquote><div class="card-actions">${btn('topic-feedback','查看反馈','text',`data-id="${t.id}"`)}${btn('edit-topic','管理主题','text',`data-id="${t.id}"`)}${t.status==='candidate'?btn('confirm-topic','确认','secondary',`data-id="${t.id}"`):t.status==='confirmed'?btn('topic-requirement','创建需求','secondary',`data-id="${t.id}"`):''}</div></section>`;}).join(''):empty('还没有主题','导入反馈后可分析并确认主题。')}</div>`;
}

function requirementsPage(p) {
  const params=route().params;
  const items=p.requirements.filter(r=>(!params.get('status')||r.status===params.get('status'))&&(!params.get('priority')||r.priority===params.get('priority')));
  return `<div class="notice-inline">${icon('list')} 需求优先级由你判断；关联来源在创建时保存快照，后续主题变化不会自动增加反馈。</div><div class="filterbar"><select data-filter="status" aria-label="需求状态筛选"><option value="">全部状态</option>${['pending','planned','in_progress','done','rejected'].map(k=>`<option value="${k}" ${params.get('status')===k?'selected':''}>${reqLabels[k]}</option>`).join('')}</select><select data-filter="priority" aria-label="需求优先级筛选"><option value="">全部优先级</option>${['unset','low','medium','high'].map(k=>`<option value="${k}" ${params.get('priority')===k?'selected':''}>${reqLabels[k]}</option>`).join('')}</select>${btn('clear-requirement-filters','清除筛选','text')}</div><section class="panel table-panel">${items.length ? `<div class="table-scroll"><table><thead><tr><th>需求与来源</th><th>优先级</th><th>状态</th><th>创建日期</th><th></th></tr></thead><tbody>${items.map(r=>`<tr><td class="feedback-content"><button data-action="requirement-detail" data-id="${r.id}">${esc(r.title)}</button><small>${r.sources.length} 条来源反馈 <span>·</span> ${esc([...new Set(r.sources.map(s=>s.topicName))].join('、'))}</small></td><td>${tag(reqLabels[r.priority],r.priority==='high'?'amber':'')}</td><td>${tag(reqLabels[r.status],r.status==='done'?'green':'')}</td><td class="subtle">${esc(localDate(r.createdAt))}</td><td><button class="icon-btn" data-action="requirement-detail" data-id="${r.id}" aria-label="查看需求">${icon('arrow')}</button></td></tr>`).join('')}</tbody></table></div>` : empty(p.requirements.length?'没有符合筛选的需求':'还没有需求','可以清除筛选，或选择反馈创建需求。',p.requirements.length?btn('clear-requirement-filters','清除筛选'):btn('nav-feedback','查看用户反馈'))}</section>`;
}

function openModal(title, body, wide=false) {
  if(modal.open&&formDirty&&!window.confirm('有未保存的修改，确认放弃并打开新窗口？'))throw new Error('已保留当前编辑内容。');
  formDirty = false;
  modal.className = wide ? 'wide-modal' : '';
  modal.innerHTML = `<div class="modal-header"><h2 id="modal-title">${title}</h2><button class="close" data-action="close" aria-label="关闭">×</button></div><div class="modal-content">${body}<p id="form-error" class="form-error" role="alert"></p></div>`;
  if (!modal.open) modal.showModal();
}
function formError(e) { const box=modal.open && $('#form-error',modal); if(box) box.textContent=e.message; else toast(e.message); }
function attempt(fn) { try { fn(); } catch(e) { formError(e); } }
function updateFilter(key,value) { const {name,params}=route();value ? params.set(key,value):params.delete(key);if(params.get('from')&&params.get('to')&&params.get('from')>params.get('to')){toast('起始日期不能晚于结束日期。');render();return;}selected.clear(); page=1; location.hash=`${name}?${params}`; render(); }

function openDetail(id) {
  const p=projectOf(state), f=p.feedback.find(f=>f.id===id); if(!f) return toast('反馈不存在。');
  openModal('反馈详情', `<div class="detail-meta">${tag(f.origin)}${reviewTag(f)}<span>${esc(f.date||'时间未知')}</span></div><h3 class="field-label">原始反馈</h3><blockquote class="original">${esc(f.content)}</blockquote><p class="footnote">${esc(f.source)} · ${esc(f.platform||'平台未知')} · 当前修订 ${f.revision}</p>${f.summary ? `<h3 class="field-label">AI 摘要与证据</h3><p>${esc(f.summary)}</p><blockquote class="original">${esc(f.evidenceQuote || '')}</blockquote><p class="footnote">${esc((f.reviewReasons || []).join('、'))} · 已保留 ${(f.aiVersions || []).length} 个真实分析版本</p>` : ''}${f.lastAiError ? `<p class="form-error">最近分析失败：${esc(f.lastAiError)}</p>` : ''}<div class="notice-inline">${icon('spark')} ${esc(f.origin)}结果，请以原文为依据审核。</div><form id="review-form"><label>摘要<textarea name="summary" rows="3" maxlength="200" required>${esc(f.summary||[...f.content].slice(0,200).join(''))}</textarea></label><label>主主题<select name="topicId">${p.topics.map(t=>`<option value="${t.id}" ${t.id===f.topicId?'selected':''}>${esc(t.name)}${t.status==='candidate'?'（候选，需先确认）':''}</option>`).join('')}</select></label><div class="form-grid"><label>情绪<select name="sentiment">${['positive','neutral','negative','uncertain'].map(k=>`<option value="${k}" ${k===f.sentiment?'selected':''}>${labels[k]}</option>`).join('')}</select></label><label>问题类型<select name="issueType">${['feature_request','bug','usability','performance','other','uncertain'].map(k=>`<option value="${k}" ${k===f.issueType?'selected':''}>${labels[k]}</option>`).join('')}</select></label></div><div class="form-actions"><button class="btn text danger" type="button" data-action="reject-feedback" data-id="${f.id}" data-revision="${f.revision}">拒绝分类</button><button class="btn primary" type="submit">${icon('check')}保存审核</button></div></form><p class="footnote">已记录 ${f.history.length} 次审核变更。拒绝后保留原文，并从分类统计中移除。</p>`);
  $('#review-form').addEventListener('submit', e=>{e.preventDefault();attempt(()=>{const data=Object.fromEntries(new FormData(e.target));const changed=['topicId','sentiment','issueType','summary'].some(k=>data[k]!==f[k]);commit(p=>reviewFeedback(p,id,f.revision,changed?'modified':'confirmed',data));modal.close();render();toast('审核已保存到当前浏览器。');});});
}

function openRequirement(ids) {
  const p=projectOf(state), fs=ids.map(id=>p.feedback.find(f=>f.id===id)).filter(Boolean);
  if(!fs.length) return toast('请先在反馈列表勾选来源反馈，或从主题创建需求。');
  if(fs.length>200 || fs.some(f=>!effective(f))) return toast('最多选择 200 条反馈，且必须有有效分类。');
  const revisionMap = fs.map(f=>[f.id,f.revision]);
  openModal('从反馈创建需求', `<p class="subtle">保留 ${fs.length} 条来源反馈的当前快照，后续新增反馈不会自动加入。</p><form id="requirement-form"><label>需求标题<input name="title" required maxlength="120" placeholder="例如：Agent 应用代码前支持差异预览"></label><label>需求描述<textarea name="description" rows="3" maxlength="5000" placeholder="记录问题、预期行为，以及需要进一步验证的假设"></textarea></label><label>优先级<select name="priority"><option value="unset">未设置</option><option value="low">低</option><option value="medium">中</option><option value="high">高</option></select></label>${requirementFields(esc)}<div class="source-list">${fs.map(f=>`<div>${tag(topicOf(p,f)?.name||'未归类')} ${reviewTag(f)}<p>${esc(f.content)}</p></div>`).join('')}</div>${fs.some(f=>!isReviewed(f))?'<label class="checkbox-label"><input name="acknowledge" type="checkbox" required>来源包含未审核建议，我已查看来源，仍创建需求。</label>':''}<div class="form-actions"><button class="btn secondary" type="button" data-action="close">取消</button><button class="btn primary" type="submit">创建并关联来源</button></div></form>`, true);
  $('#requirement-form').addEventListener('submit',e=>{e.preventDefault();attempt(()=>{const data=Object.fromEntries(new FormData(e.target));commit(p=>{if(revisionMap.some(([id,rev])=>p.feedback.find(f=>f.id===id)?.revision!==rev))throw new Error('来源已变化，请关闭后重新选择。');const req=createRequirement(p,data,ids,Boolean(data.acknowledge));Object.assign(req,requirementExtras(data));});modal.close();go('requirements');toast('需求已创建，来源快照已保留。');});});
}

function requirementDetail(id) {
  const p=projectOf(state), r=p.requirements.find(r=>r.id===id); if(!r) return toast('需求不存在。');
  const next={pending:['planned','rejected'],planned:['pending','in_progress','rejected'],in_progress:['planned','done'],done:['in_progress'],rejected:['pending']}[r.status];
  openModal('需求详情',`<h3>${esc(r.title)}</h3><div class="detail-meta">${tag(reqLabels[r.status])}${tag('优先级：'+reqLabels[r.priority])}</div><p class="description-text">${esc(r.description||'暂无描述')}</p>${REQUIREMENT_FIELDS.map(([key,label])=>`<h3 class="field-label">${label}</h3><p class="description-text">${esc(r[key]||'尚未填写')}</p>`).join('')}<p>效果验证：${esc({not_checked:'尚未验证',checked:'已记录验证',inconclusive:'暂不能判断'}[r.verificationState||'not_checked'])}</p>${btn('export-requirement','导出需求 Markdown','text',`data-id="${r.id}"`)}<h3 class="field-label">关联时来源快照 · ${r.sources.length} 条</h3><div class="source-list">${r.sources.map(s=>`<div>${tag(s.topicName)} ${tag(s.origin)}<p>${esc(s.content)}</p><small>创建时：${labels[s.review]} · 当前：${labels[p.feedback.find(f=>f.id===s.id)?.review]||'来源不可用'}</small></div>`).join('')}</div>${btn('edit-requirement','编辑内容与来源','secondary',`data-id="${r.id}"`)}<form id="status-form"><label>更新状态<select name="status"><option value="${r.status}">${reqLabels[r.status]}（当前）</option>${next.map(k=>`<option value="${k}">${reqLabels[k]}</option>`).join('')}</select></label>${['done','rejected'].includes(r.status)?'<label class="checkbox-label"><input type="checkbox" name="confirm">确认重新打开该需求</label>':''}<div class="form-actions"><button class="btn primary" type="submit">保存状态</button></div></form>`);
  $('#status-form').addEventListener('submit',e=>{e.preventDefault();attempt(()=>{const data=Object.fromEntries(new FormData(e.target));commit(p=>{const current=p.requirements.find(x=>x.id===id);if(current.revision!==r.revision)throw new Error('需求已变化，请重新打开。');assertTransition(current.status,data.status,Boolean(data.confirm));if(data.status!==current.status&&data.status==='planned'&&!current.decisionReason?.trim())throw new Error('请先编辑需求，填写决策理由后再标记已规划。');if(data.status!==current.status&&data.status==='done'&&(!current.acceptanceCriteria?.trim()||!current.completionNote?.trim()))throw new Error('请先编辑需求，填写验收条件与完成说明。完成开发不等于效果已验证。');current.status=data.status;current.revision++;current.updatedAt=new Date().toISOString();});modal.close();render();toast('需求状态已保存。');});});
}

function openImport() {
  importData=null;
  openModal('导入用户反馈',`<div class="import-steps"><b>01 选择文件</b><span>02 映射与校验</span><span>03 导入结果</span></div><div class="upload-area">${icon('upload')}<h3>把用户声音带进工作区</h3><p>UTF-8 CSV · 最多 5 MiB / 2,000 行 / 50 列</p><label class="btn primary file-label">选择 CSV 文件<input id="file-input" type="file" accept=".csv,text/csv"></label><a class="link" href="./sample-feedback.csv" download>下载示例 CSV</a></div><div class="notice-inline">文件仅在当前浏览器解析。请勿导入敏感或无权处理的数据；导入不会自动发送给 AI；仅在你选择反馈并确认真实分析后，才发送所选的脱敏正文。</div>`,true);
  $('#file-input').addEventListener('change',async e=>{const file=e.target.files[0];if(!file)return;try{if(!file.name.toLowerCase().endsWith('.csv'))throw new Error('请选择 .csv 文件。');if(file.size>5*1024*1024)throw new Error('文件不能超过 5 MiB。');const bytes=new Uint8Array(await file.arrayBuffer());const table=parseCsv(bytes);const hash=await crypto.subtle.digest('SHA-256',bytes);importData={table,fileName:file.name,fileHash:Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join(''),projectId:projectOf(state).id};showMapping();}catch(e){formError(e);}});
}
function showMapping() {
  const {table,fileName}=importData;
  openModal('映射字段与校验',`<div class="import-steps"><span>01 选择文件</span><b>02 映射与校验</b><span>03 导入结果</span></div><p>${esc(fileName)} · ${table.rows.length} 条数据行</p><form id="mapping-form"><div class="form-grid">${[['content','反馈正文 *'],['source','来源渠道'],['external_id','外部 ID'],['platform','平台'],['rating','评分（1—5）'],['feedback_at','反馈时间'],['app_version','App 版本']].map(([key,label])=>`<label>${label}<select name="${key}"><option value="">${key==='content'?'请选择':'不导入'}</option>${table.headers.map((h,i)=>`<option value="${i}" ${({'正文':'content','content':'content','来源':'source','外部ID':'external_id','平台':'platform','评分':'rating','反馈时间':'feedback_at','日期':'feedback_at','App版本':'app_version'})[h]===key?'selected':''}>${esc(h||'空表头')}（第 ${i+1} 列）</option>`).join('')}</select></label>`).join('')}</div><p class="footnote">日期支持 YYYY-MM-DD 或 ISO 时间；未带时区按香港时间解析，空值为时间未知。空行跳过，错误行不会导入；跨文件无外部 ID 的相似反馈不会自动去重。</p><button class="btn primary" type="submit">校验全部行并预览</button></form>`,true);
  $('#mapping-form').addEventListener('submit',e=>{e.preventDefault();attempt(()=>{const data=Object.fromEntries(new FormData(e.target));if(data.content==='')throw new Error('必须映射反馈正文。');const mapping=Object.fromEntries(Object.entries(data).filter(([,v])=>v!=='').map(([k,v])=>[k,Number(v)]));const results=validateRows(table,mapping);importData.results=results;showPreview();});});
}
function rowKeys(row) {const v=row.values;return [JSON.stringify(['file',importData.fileHash,row.recordNo]),...(v?.external_id?[JSON.stringify(['source',v.source,v.external_id])]:[])];}
function resolveImportRows(p) {
  const keys=new Set(p.feedback.flatMap(f=>f.keys||[]));
  return importData.results.map(row=>{if(row.status!=='valid')return {...row,outcome:row.status};const rk=rowKeys(row);if(rk.some(k=>keys.has(k)))return {...row,outcome:'duplicate'};rk.forEach(k=>keys.add(k));return {...row,outcome:'new',keys:rk};});
}
function showPreview() {
  const rows=resolveImportRows(projectOf(state));importData.resolved=rows;
  const count=status=>rows.filter(r=>r.outcome===status).length;
  openModal('确认导入预览',`<div class="import-steps"><span>01 选择文件</span><b>02 映射与校验</b><span>03 导入结果</span></div><div class="import-counts">${[['new','可导入'],['invalid','错误行'],['empty','空行'],['duplicate','重复行']].map(([k,l])=>`<div><strong>${count(k)}</strong><span>${l}</span></div>`).join('')}</div><p class="subtle">已校验全文件，以下仅预览前 20 条；错误和重复行将跳过。</p><div class="preview-scroll"><table><thead><tr><th>原记录号</th><th>正文 / 错误说明</th><th>结果</th></tr></thead><tbody>${rows.slice(0,20).map(r=>`<tr><td>${r.recordNo}</td><td>${esc(r.errors.length?r.errors.join('；'):r.values?.content||'空行')}</td><td>${tag({new:'可导入',invalid:'错误',empty:'跳过',duplicate:'重复'}[r.outcome],r.outcome==='invalid'?'amber':'')}</td></tr>`).join('')}</tbody></table></div><div class="form-actions">${btn('import-errors','导出错误报告','text')}${btn('import-remap','返回映射','secondary')}${btn('confirm-import',`导入 ${count('new')} 条有效反馈`,'primary',count('new')?'':'disabled')}</div>`,true);
}
function confirmImport() {
  if(!importData || projectOf(state).id!==importData.projectId)throw new Error('项目已变化，请重新导入。');
  const rows=resolveImportRows(projectOf(state)), fresh=rows.filter(r=>r.outcome==='new');
  if(projectOf(state).feedback.length+fresh.length>10000)throw new Error('导入后将超过本机项目 10,000 条反馈上限，请减少本批数据或使用新项目。');
  commit(p=>{for(const row of fresh){const v=row.values;p.feedback.unshift({id:uid(),content:v.content,source:v.source||'CSV 导入',platform:v.platform||'',date:v.date||null,feedbackAt:v.feedback_at||null,rating:v.rating,appVersion:v.app_version||'',topicId:null,sentiment:'uncertain',issueType:'uncertain',review:'pending',origin:'待分析',analysisStatus:'queued',revision:0,history:[],keys:row.keys});}p.imports.unshift({id:uid(),fileName:importData.fileName,fileHash:importData.fileHash,createdAt:new Date().toISOString(),rows:rows.map(r=>({recordNo:r.recordNo,outcome:r.outcome,errors:r.errors})),total:rows.length,imported:fresh.length,invalid:rows.filter(r=>r.outcome==='invalid').length,skipped:rows.filter(r=>['empty','duplicate'].includes(r.outcome)).length});});
  openModal('导入完成',`<div class="success-icon">${icon('check')}</div><h3>已新增 ${fresh.length} 条反馈</h3><p>总计 ${rows.length} 条 · 错误 ${rows.filter(r=>r.outcome==='invalid').length} 条 · 跳过 ${rows.filter(r=>['empty','duplicate'].includes(r.outcome)).length} 条</p><div class="notice-inline">导入完成不代表 AI 分析完成。你可以运行明确标记的本地关键词模拟；它不调用 DeepSeek，也不代表真实模型效果。</div><div class="form-actions">${btn('import-errors','导出错误报告','text')}${btn('show-imported','先查看反馈','secondary')}${btn('simulate','运行模拟分类','primary')}</div>`,true);
  render();
}
function simulate() {
  commit(p=>{for(const f of p.feedback.filter(f=>f.analysisStatus==='queued')){const result=classifyMock(f.content);let t=p.topics.find(t=>normalizeTopicName(t.name)===normalizeTopicName(result.name));if(t?.status==='archived')throw new Error('模拟匹配主题已归档，请先恢复该主题或使用真实分析。');if(!t){t={id:uid(),name:result.name,status:'candidate',description:'来自本地关键词模拟的候选主题，需人工确认。'};p.topics.push(t);}Object.assign(f,{topicId:t.id,sentiment:result.sentiment,issueType:result.issueType,origin:'关键词模拟',analysisStatus:'succeeded',revision:f.revision+1});}});
  modal.close();go('feedback');toast('模拟分类完成，结果仍待人工审核。');
}
function download(name,content,type='application/json') {const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function about() {openModal('关于这份公开演示',`<div class="about-logo"><img src="./favicon.svg" alt="" width="42" height="42"><strong>InsightFlow</strong>${tag('MVP 交互演示','green')}</div><p>为软件 App 产品经理与独立开发者设计，把零散用户反馈整理为可核查、可跟进的需求。</p><ol class="about-list"><li>示例项目与反馈均为合成数据；预设分类不是实际 AI 运行结果。</li><li>上传文件只在浏览器解析；“模拟分类”使用关键词规则，不调用 DeepSeek。</li><li>审核与需求变化保存在本机浏览器，不跨设备同步，清理站点数据会丢失。</li><li>静态演示不要求登录、不含密钥；云端或本地接口可显式启用真实 AI；发送前需确认，调用会消耗作者的额度。</li><li>云端接口只负责限额与真实 AI 分析；反馈仍存当前浏览器，尚无后台队列、多账号或跨设备同步。</li></ol><div class="form-actions">${btn('backup','导出浏览器数据','secondary')}${btn('close','开始探索','primary')}</div>`);}

document.addEventListener('click',e=>{
  const b=e.target.closest('[data-action]');if(!b||b.disabled)return;
  const action=b.dataset.action,id=b.dataset.id;
  attempt(()=>{
    const p=projectOf(state);
    if(action==='close'){if(!formDirty || window.confirm('有未保存的修改，确认放弃并关闭？')){formDirty=false;modal.close();}}
    else if(action==='ai-settings')aiSettings();
    else if(action==='refresh-ai')refreshBackend().then(()=>{aiSettings();render();});
    else if(action==='real-ai')startRealAi();
    else if(action==='confirm-real-ai')runRealAi().catch(formError);
    else if(action==='stop-real-ai'){if(realAiRun){realAiRun.stop=true;toast('将完成当前请求后停止，当前请求可能已产生费用。');}}
    else if(action==='about')about();
    else if(action==='import')openImport();
    else if(action==='manual-feedback')products.manualFeedback();
    else if(action==='export-requirement')products.exportRequirement(id);
    else if(action==='export-feedback'){const rows=filtered();if(!rows.length)throw new Error('当前筛选没有反馈可导出。');const headers=['反馈原文','来源','平台','App 版本','反馈日期','主主题','情绪','问题类型','分析状态','审核状态','分析来源'];download('insightflow-feedback.csv','\uFEFF'+[headers,...rows.map(f=>[f.content,f.source,f.platform,f.appVersion,f.date,topicOf(p,f)?.name||'',labels[f.sentiment],labels[f.issueType],f.analysisStatus,labels[f.review],f.origin])].map(row=>row.map(escapeCsvCell).join(',')).join('\r\n'),'text/csv;charset=utf-8');toast(`已导出当前筛选的 ${rows.length} 条反馈。`);}
    else if(action==='detail')openDetail(id);
    else if(action==='nav-topics')go('topics');
    else if(action==='nav-feedback')go('feedback');
    else if(action==='review-pending')go('feedback',{review:'pending'});
    else if(action==='scope-all'||action==='scope-reviewed'){const query=Object.fromEntries(route().params);delete query.scope;if(action==='scope-reviewed')query.scope='reviewed';go('overview',query);}
    else if(action==='topic-feedback')go('feedback',{...Object.fromEntries(route().params),topic:id});
    else if(action==='clear-filters')go(route().name==='overview'?'overview':'feedback');
    else if(action==='clear-requirement-filters')go('requirements');
    else if(action==='select-visible'){filtered().slice((page-1)*20,page*20).forEach(f=>selected.add(f.id));render();}
    else if(action==='prev-page'){page=Math.max(1,page-1);render();}
    else if(action==='next-page'){page++;render();}
    else if(action==='confirm-topic'){const topic=p.topics.find(t=>t.id===id);commit(p=>setTopicStatus(p,id,topic.revision||0,'confirmed'));render();toast('主题已确认，关联反馈仍需分别审核。');}
    else if(action==='edit-topic')panels.topicEditor(id);
    else if(action==='archive-topic'||action==='restore-topic')panels.topicStatus(id,Number(b.dataset.revision),action==='archive-topic'?'archived':'confirmed');
    else if(action==='edit-requirement')panels.requirementEditor(id);
    else if(action==='import-history')panels.history();
    else if(action==='import-history-detail')panels.historyDetail(id);
    else if(action==='analysis-history')panels.analysisHistory();
    else if(action==='analysis-history-detail')panels.analysisHistoryDetail(id);
    else if(action==='restore-backup')panels.restore();
    else if(action==='batch-confirm'){
      if(!selected.size||selected.size>200)throw new Error('请选择 1—200 条待审核反馈。');
      const ids=[...selected], feedback=ids.map(id=>p.feedback.find(f=>f.id===id));
      if(feedback.some(f=>!f||f.review!=='pending'||f.analysisStatus!=='succeeded'))throw new Error('选择中含非待审核或未分析反馈，请筛选“待审核”后重新选择。');
      if(new Set(feedback.map(f=>f.topicId)).size!==1)throw new Error('批量确认仅支持同一主题。请先按主题筛选，再选择待审核反馈。');
      const topic=p.topics.find(t=>t.id===feedback[0].topicId);
      if(!topic||topic.status!=='confirmed')throw new Error('请先在主题页确认候选主题；已归档主题不能批量审核。');
      const revisions=new Map(feedback.map(f=>[f.id,f.revision]));
      openModal('确认批量审核',`<p>将确认主题「${esc(topic.name)}」下的 ${ids.length} 条反馈。请核查每条原文；确认后记录人工审核结果。</p><div class="source-list">${feedback.map(f=>`<div><p>${esc(f.content)}</p>${tag(labels[f.sentiment])}</div>`).join('')}</div><div class="form-actions">${btn('close','取消','secondary')}<button id="confirm-batch-review" class="btn primary">确认这 ${ids.length} 条反馈</button></div>`,true);
      $('#confirm-batch-review').addEventListener('click',()=>attempt(()=>{
        commit(p=>{for(const id of ids){const f=p.feedback.find(f=>f.id===id);if(!f||f.review!=='pending'||f.topicId!==topic.id)throw new Error('反馈已变化，请重新选择并核查。');reviewFeedback(p,id,revisions.get(id),'confirmed');}});
        selected.clear();modal.close();render();toast('所选反馈已确认。');
      }));
    }
    else if(action==='reject-feedback'){commit(p=>reviewFeedback(p,id,Number(b.dataset.revision),'rejected'));modal.close();render();toast('已拒绝分类，原文保留。');}
    else if(action==='new-requirement'){go('feedback');toast('请勾选来源反馈，再点击“转为需求”。');}
    else if(action==='selected-requirement')openRequirement([...selected]);
    else if(action==='topic-requirement')openRequirement(p.feedback.filter(f=>f.topicId===id&&effective(f)).map(f=>f.id));
    else if(action==='requirement-detail')requirementDetail(id);
    else if(action==='import-remap')showMapping();
    else if(action==='confirm-import'){b.disabled=true;try{confirmImport();}catch(error){b.disabled=false;throw error;}}
    else if(action==='simulate')simulate();
    else if(action==='show-imported'){modal.close();go('feedback');}
    else if(action==='import-errors'){if(!importData?.results)throw new Error('没有可导出的错误。');const rows=importData.results.filter(r=>r.status==='invalid');download('insightflow-import-errors.csv','\uFEFF'+[['原记录号','错误原因','原始内容'],...rows.map(r=>[r.recordNo,r.errors.join('；'),r.values?.raw_text||''])].map(row=>row.map(escapeCsvCell).join(',')).join('\r\n'),'text/csv;charset=utf-8');}
    else if(action==='backup'){let raw;try{raw=localStorage.getItem(STORAGE_KEY);}catch{}download('insightflow-demo-backup.json',raw||JSON.stringify(state,null,2));toast('备份含本机反馈原文，请妥善保管。');}
    else if(action==='reset'){openModal('重置当前浏览器的演示？','<p>将清除所有演示项目、导入反馈和需求，恢复初始示例。可以先导出备份。</p><div class="form-actions">'+btn('backup','先导出备份','secondary')+btn('reset-confirm','确认重置','primary')+'</div>');}
    else if(action==='reset-confirm'){const next=initialState();saveState(localStorage,next);state=next;storageError='';storageCorrupt=false;selected.clear();modal.close();go('overview');toast('演示已重置。');}
    else if(action==='new-project'){
      openModal('创建 App 项目','<form id="project-form"><label>项目名称<input name="name" required maxlength="80" placeholder="例如：我的 App"></label><label>App 名称<input name="appName" required maxlength="120" placeholder="产品名称"></label><p class="footnote">新项目独立保存反馈、主题和需求，仍属于当前浏览器内的演示数据。</p><div class="form-actions"><button class="btn primary" type="submit">创建项目</button></div></form>');
      $('#project-form').addEventListener('submit',e=>{e.preventDefault();attempt(()=>{const data=Object.fromEntries(new FormData(e.target));if(!data.name.trim()||!data.appName.trim())throw new Error('名称不能全为空白。');commit((_p,s)=>{const id=uid();s.projects.push({id,name:data.name.trim(),appName:data.appName.trim(),feedback:[],topics:[],requirements:[],imports:[],isSample:false});s.activeProjectId=id;});modal.close();go('overview');});});
    }
  });
});

window.addEventListener('hashchange',()=>{selected.clear();page=1;render();});
modal.addEventListener('input',()=>{formDirty=true;});
modal.addEventListener('cancel',e=>{if(formDirty&&!window.confirm('有未保存的修改，确认放弃并关闭？'))e.preventDefault();});
modal.addEventListener('close',()=>{formDirty=false;if(realAiRun&&!realAiRun.confirmed)realAiRun=null;});
window.addEventListener('beforeunload',e=>{if((modal.open&&formDirty)||realAiRun?.confirmed){e.preventDefault();e.returnValue='';}});
window.addEventListener('pagehide',()=>{if(realAiRun?.confirmed){try{commit((_p,s)=>{const log=s.projects.find(p=>p.id===realAiRun.projectId)?.analysisRuns.find(r=>r.id===realAiRun.journalId);if(log){log.status='interrupted';for(const i of log.items){if(i.status==='running')i.status='unknown';else if(i.status==='queued')i.status='not_started';}}});}catch{}}});
setInterval(()=>{if(!realAiRun?.confirmed&&!storageCorrupt){const next=structuredClone(state);if(recoverInterruptedRuns(next)){try{saveState(localStorage,next);state=next;render();}catch(e){toast(e.message);}}}},30_000);
window.addEventListener('storage',e=>{if(e.key===STORAGE_KEY){try{state=loadState(localStorage);selected.clear();if(modal.open&&formDirty){render();formError(new Error('另一标签页已更新数据。当前草稿保留；保存时若发生冲突，请复制草稿后重新打开。'));}else{modal.close();render();toast('检测到另一标签页的数据变化，已刷新。');}}catch(error){storageError=error.message;storageCorrupt=true;render();}}});
render();
refreshBackend().then(render);
