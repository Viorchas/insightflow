import { makeExpandedRows } from './seed-expansion.mjs';
export const STORAGE_KEY = 'insightflow-demo-v1';
export const SCHEMA_VERSION = 1;
export const uid = () => crypto.randomUUID();
const rows = [
  ['让 chatagent 修改登录组件，它却改了不相关的配置文件，希望应用前能逐文件确认。', 'coding', 'negative', 'feature_request', 'pending', 'Windows'],
  ['代码修改前如果能显示差异预览，我会更放心让 Agent 处理整个项目。', 'coding', 'neutral', 'feature_request', 'confirmed', 'macOS'],
  ['连续聊了十几轮后，之前说好的技术栈又被忘了，总要重新解释。', 'context', 'negative', 'usability', 'modified', 'Web'],
  ['上传扫描版 PDF 后回答一直说没有正文，希望告诉我是否支持 OCR。', 'files', 'negative', 'usability', 'pending', 'Web'],
  ['问到某个接口的参数，给出的函数根本不存在，回答却很确定。', 'quality', 'negative', 'bug', 'confirmed', 'Web'],
  ['希望代码修改后能一键撤销这轮操作，而不是手动逐个还原文件。', 'coding', 'neutral', 'feature_request', 'pending', 'Windows'],
  ['这次回答附上了可打开的来源链接，核对资料方便很多。', 'quality', 'positive', 'usability', 'confirmed', 'Android'],
  ['发送简单问题后要等很久才开始输出，希望显示当前是在排队还是思考。', 'speed', 'negative', 'performance', 'pending', 'Web'],
  ['让它继续修改上一轮的代码，结果重新生成了另一套实现。', 'context', 'negative', 'usability', 'confirmed', 'macOS'],
  ['引用 PDF 的结论时，希望附上页码和原文片段，方便核查。', 'files', 'neutral', 'feature_request', 'pending', 'Web'],
  ['明明提示还有额度，发消息后却说次数用完了，规则看不明白。', 'quota', 'negative', 'usability', 'pending', 'iOS'],
  ['新版本开始输出更快了，长回答边生成边阅读比较顺畅。', 'speed', 'positive', 'performance', 'confirmed', 'Android'],
  ['Agent 修改代码后没有说明改了哪些文件，我不敢直接提交。', 'coding', 'negative', 'usability', 'modified', 'Windows'],
  ['希望切换模型时保留当前对话上下文，不用重新粘贴需求。', 'context', 'neutral', 'feature_request', 'pending', 'Web'],
  ['上传表格后把金额列认成了日期，能不能先预览识别结果？', 'files', 'negative', 'bug', 'pending', 'Web'],
  ['生成长代码时偶尔断流，重新发送又从头来，希望能从中断位置继续。', 'speed', 'negative', 'bug', 'confirmed', 'macOS'],
  ['查资料的回答里有几个引用链接打不开，希望标明检索时间和来源。', 'quality', 'negative', 'bug', 'pending', 'Web'],
  ['能解释为什么要改这段代码，并给出对应测试思路，这点挺有帮助。', 'coding', 'positive', 'usability', 'confirmed', 'macOS'],
  ['想知道这次 Agent 任务用了多少额度，运行前最好能看到消耗规则。', 'quota', 'neutral', 'feature_request', 'pending', 'Windows'],
  ['长对话能记住我前面指定的输出格式，省了反复说明。', 'context', 'positive', 'usability', 'confirmed', 'iOS'],
  ['同一问题重复提问时答案相互矛盾，希望不确定时明确告诉我。', 'quality', 'negative', 'usability', 'confirmed', 'Android'],
  ['附件上传失败只显示红色图标，不知道是文件太大还是格式不支持。', 'files', 'negative', 'usability', 'pending', 'iOS'],
  ['任务运行到一半提示额度不足，希望提前提醒并允许保存当前进度。', 'quota', 'negative', 'feature_request', 'pending', 'Web'],
  ['代码执行卡住后看不到进度，也找不到停止按钮。', 'speed', 'negative', 'usability', 'modified', 'Windows'],
];

export function initialState() {
  const projectId = uid();
  const topics = [
    { id: 'coding', name: 'Agent 编程与修改控制', status: 'confirmed', description: '代码差异预览、修改范围、变更说明与撤销能力' },
    { id: 'context', name: '上下文与对话记忆', status: 'confirmed', description: '长对话遗忘、多轮指令一致性与切换模型时的上下文保留' },
    { id: 'quality', name: '回答可靠性与引用', status: 'confirmed', description: '事实错误、虚构接口、来源可核查性与不确定性表达' },
    { id: 'speed', name: '响应速度与任务状态', status: 'confirmed', description: '首字等待、排队与思考状态、断流恢复及任务停止' },
    { id: 'files', name: '文件理解与证据定位', status: 'candidate', description: 'PDF 与表格识别、上传错误、页码引用及原文证据' },
    { id: 'quota', name: '使用额度与消耗透明', status: 'candidate', description: '额度显示、消耗规则、运行前提醒与进度保留' },
  ];
  const feedback = [...rows, ...makeExpandedRows()].map((r, i) => ({ dataKind: 'synthetic', seedId: `chatagent-feedback-${i + 1}`, id: uid(), content: r[0], topicId: r[1], sentiment: r[2], issueType: r[3], review: r[4], platform: r[5], source: ['产品内反馈', '开发者社区', '用户访谈', 'App 商店'][i % 4], date: i < rows.length ? `2026-10-${String(6 + Math.floor(i / 2)).padStart(2, '0')}` : new Date(Date.UTC(2026, 8, 20 + (i - rows.length) % 30)).toISOString().slice(0, 10), origin: '示例预设', analysisStatus: 'succeeded', revision: 0, history: [], keys: [] }));
  const source = feedback.find(f => f.topicId === 'coding' && f.review === 'confirmed');
  const req = { id: uid(), title: 'Agent 应用代码修改前支持逐文件差异确认', description: '用户需要先核查修改范围再应用代码。建议展示逐文件差异、允许取消本轮操作，并保留来源反馈用于后续验证。此条为合成数据示例，尚无真实价值或效果结论。', priority: 'medium', status: 'pending', sources: [snapshot(source, topics)], createdAt: '2026-10-15T08:00:00.000Z', revision: 0 };
  return { version: SCHEMA_VERSION, activeProjectId: projectId, projects: [{ id: projectId, name: 'chatagent', appName: 'chatagent · AI 工作台', description: '虚构的通用对话与 Agent 编程平台，覆盖资料问答、文件理解与代码修改场景', seedKey: 'chatagent-v1', sampleRevision: 2, topics, feedback, requirements: [req], imports: [], isSample: true }] };
}

export function projectOf(state) {
  return state.projects.find(p => p.id === state.activeProjectId) || state.projects[0];
}
export function effective(f) { return f.analysisStatus === 'succeeded' && f.review !== 'rejected'; }
export function isReviewed(f) { return f.review === 'confirmed' || f.review === 'modified'; }
export function snapshot(f, topics) {
  return { id: f.id, content: f.content, topicName: topics.find(t => t.id === f.topicId)?.name || '未归类', origin: f.origin, review: f.review, revision: f.revision };
}
export function classifyMock(text) {
  const groups = [
    [/额度|计费|消耗|次数|扣费/, '使用额度与消耗透明', 'usability'],
    [/附件|上传|PDF|表格|页码|OCR/i, '文件理解与证据定位', 'usability'],
    [/上下文|记忆|忘|多轮|上一轮|长对话|切换模型/, '上下文与对话记忆', 'usability'],
    [/排队|思考状态|首字|断流|中断|卡住|停止|进度|慢|等待|流畅/, '响应速度与任务状态', 'performance'],
    [/代码|编程|撤销|差异|配置文件|Agent/i, 'Agent 编程与修改控制', 'feature_request'],
    [/引用|来源|事实|虚构|接口|矛盾|不确定|回答/, '回答可靠性与引用', 'usability'],
  ];
  const match = groups.find(([regex]) => regex.test(text));
  return { name: match?.[1] || '待梳理反馈', issueType: match?.[2] || 'uncertain', sentiment: /失败|错误|慢|卡|不|麻烦/.test(text) ? 'negative' : /喜欢|方便|流畅/.test(text) ? 'positive' : 'neutral' };
}

export function reviewFeedback(project, id, revision, action, changes = {}) {
  const f = project.feedback.find(f => f.id === id);
  if (!f || f.revision !== revision) throw new Error('反馈已变化，请重新打开详情。');
  if (f.analysisStatus !== 'succeeded') throw new Error('反馈尚无有效分析结果，请先完成分析。');
  if (!['confirmed', 'modified', 'rejected'].includes(action)) throw new Error('不支持的审核动作。');
  if (Object.keys(changes).some(k=>!['topicId','sentiment','issueType','summary'].includes(k))) throw new Error('审核字段不受支持。');
  if (changes.sentiment&&!['positive','negative','neutral','uncertain'].includes(changes.sentiment)) throw new Error('情绪分类无效。');
  if (changes.issueType&&!['feature_request','bug','usability','performance','other','uncertain'].includes(changes.issueType)) throw new Error('问题类型无效。');
  if (changes.summary!==undefined && (typeof changes.summary!=='string'||!changes.summary.trim()||[...changes.summary].length>200)) throw new Error('摘要需为 1—200 字符。');
  if (action !== 'rejected') {
    const topic = project.topics.find(t => t.id === (changes.topicId || f.topicId));
    if (!topic || topic.status !== 'confirmed') throw new Error('请先在主题页确认候选主题，再审核反馈。');
  }
  f.history.push({ review: f.review, topicId: f.topicId, sentiment: f.sentiment, issueType:f.issueType, summary:f.summary||null, at: new Date().toISOString(), revision: f.revision });
  Object.assign(f, changes, { review: action, revision: f.revision + 1 });
}

export function createRequirement(project, fields, ids, acknowledge = false) {
  if(project.requirements.length>=2000)throw new Error('当前演示项目最多保留 2,000 个需求，请先备份并整理。');
  if (!fields.title?.trim() || [...fields.title.trim()].length > 120) throw new Error('请填写 1—120 字符的需求标题。');
  if ([...String(fields.description || '')].length > 5000) throw new Error('需求描述不能超过 5,000 字符。');
  if (!ids.length || ids.length > 200 || new Set(ids).size !== ids.length) throw new Error('请选择 1—200 条不重复的来源反馈。');
  const feedback = ids.map(id => project.feedback.find(f => f.id === id));
  if (feedback.some(f => !f || !effective(f))) throw new Error('来源反馈已变化或无有效分类，请重新选择。');
  if (feedback.some(f => !isReviewed(f)) && !acknowledge) throw new Error('来源包含未经审核的建议，请确认已查看来源。');
  if (!['unset', 'low', 'medium', 'high'].includes(fields.priority)) throw new Error('需求优先级无效。');
  const req = { id: uid(), title: fields.title.trim(), description: fields.description || '', priority: fields.priority, status: 'pending', sources: feedback.map(f => snapshot(f, project.topics)), createdAt: new Date().toISOString(), revision: 0 };
  project.requirements.unshift(req);
  return req;
}

export function saveState(storage, state) {
  try { storage.setItem(STORAGE_KEY, JSON.stringify(state)); }
  catch { throw new Error('浏览器存储不可用或空间不足，本次修改未保存。请导出备份或清理空间后重试。'); }
}
export function loadState(storage) {
  const raw = storage.getItem(STORAGE_KEY);
  if (!raw) return initialState();
  const data = JSON.parse(raw);
  if (data.version !== SCHEMA_VERSION || !Array.isArray(data.projects) || !data.projects.length || data.projects.some(p => !p.id || !Array.isArray(p.feedback) || !Array.isArray(p.topics) || !Array.isArray(p.requirements) || !Array.isArray(p.imports))) throw new Error('本地演示数据无法读取，请导出原始备份后重置。');
  // Add the new scenario once; preserve earlier imports, reviews and projects in full.
  if (!data.projects.some(p => p.seedKey === 'chatagent-v1')) {
    const active = projectOf(data);
    const sample = projectOf(initialState());
    data.projects.unshift(sample);
    if (active.isSample) data.activeProjectId = sample.id;
  }
  // Append new samples once, keeping prior reviews, requirements and imports intact.
  for (const project of data.projects.filter(p => p.seedKey === 'chatagent-v1' && p.isSample && (p.sampleRevision || 1) < 2)) {
    const additions = projectOf(initialState()).feedback.slice(rows.length);
    const existingIds = new Set(project.feedback.map(f => f.seedId).filter(Boolean));
    const existingContent = new Set(project.feedback.map(f => f.content));
    for (const feedback of additions) {
      const topic = project.topics.find(t => t.id === feedback.topicId);
      if (!topic || existingIds.has(feedback.seedId) || existingContent.has(feedback.content)) continue;
      if (topic.status !== 'confirmed') feedback.review = 'pending';
      project.feedback.push(feedback);
    }
    project.sampleRevision = 2;
  }
  return data;
}
