// Public demo bridge. Only quota metadata is stored; never feedback or provider responses.
import { analyzeWithDeepSeek, readDeepSeekConfig } from '../src/ai/deepseek.ts';
import { DomainError } from '../src/domain/errors.ts';

const QUOTA = { daily: 10, total: 20, perAddress: 3, maxChars: 1500, maxTopics: 30 };
async function digest(value) {
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(value)))].map(n=>n.toString(16).padStart(2,'0')).join('');
}
async function readBody(request) {
  if(!request.headers.get('content-type')?.startsWith('application/json'))throw new DomainError('INVALID_INPUT','请求必须使用 JSON。',415);
  const reader=request.body?.getReader();if(!reader)throw new DomainError('INVALID_INPUT','请求为空。');
  const chunks=[];let size=0;
  try {while(true){const {value,done}=await reader.read();if(done)break;size+=value.byteLength;if(size>16384){await reader.cancel();throw new DomainError('INVALID_INPUT','单次输入过大。',413);}chunks.push(value);}}
  finally{reader.releaseLock();}
  const bytes=new Uint8Array(size);let offset=0;for(const c of chunks){bytes.set(c,offset);offset+=c.length;}
  try{return JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes));}catch{throw new DomainError('INVALID_INPUT','JSON 内容损坏。');}
}
async function reserve(db, day, address, requestId) {
  // A single conditional UPDATE is atomic across isolates; unavailable quota storage fails closed.
  await db.prepare("CREATE TABLE IF NOT EXISTS demo_budget (id INTEGER PRIMARY KEY CHECK(id=1), day TEXT NOT NULL, used INTEGER NOT NULL, total INTEGER NOT NULL, clients TEXT NOT NULL, requests TEXT NOT NULL)").run();
  await db.prepare("INSERT OR IGNORE INTO demo_budget VALUES (1, '', 0, 0, '{}', '{}')").run();
  const path=`$.${address}`, requestPath=`$.\"${requestId}\"`;
  const result=await db.prepare(`UPDATE demo_budget SET
    day=?1, used=CASE WHEN day=?1 THEN used+1 ELSE 1 END, total=total+1,
    clients=json_set(CASE WHEN day=?1 THEN clients ELSE '{}' END, ?2, coalesce(CASE WHEN day=?1 THEN json_extract(clients, ?2) ELSE 0 END,0)+1),
    requests=json_set(requests, ?3, 1)
    WHERE id=1 AND total<?4 AND (day<>?1 OR used<?5)
    AND (day<>?1 OR coalesce(json_extract(clients, ?2),0)<?6)
    AND json_extract(requests, ?3) IS NULL
    RETURNING total`).bind(day,path,requestPath,QUOTA.total,QUOTA.daily,QUOTA.perAddress).first();
  if(!result)throw new DomainError('DEMO_QUOTA_LIMIT','本次请求重复，或真实 AI 体验额度已达上限。请保留现有结果，稍后再试或联系作者。',429);
}

export default {
  async fetch(request,env) {
    const url=new URL(request.url), origin=request.headers.get('origin');
    const allowed=['https://viorchas.github.io',url.origin];
    const headers={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Vary':'Origin'};
    if(origin&&allowed.includes(origin))headers['Access-Control-Allow-Origin']=origin;
    const reply=(status,value)=>new Response(JSON.stringify(value),{status,headers});
    const requestId=crypto.randomUUID();
    try {
      if(origin&&!allowed.includes(origin))throw new DomainError('ORIGIN_DENIED','此来源不能访问演示接口。',403);
      if(request.method==='OPTIONS')return new Response(null,{status:204,headers:{...headers,'Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, x-insightflow-token','Access-Control-Max-Age':'600'}});
      const config=readDeepSeekConfig({...env,DEEPSEEK_API_KEY:env.DEEPSEEK_API_KEY||env.deepseek_api_key}), configured=Boolean(config.apiKey&&env.DB&&env.AI_ENABLED==='true');
      if(url.pathname==='/api/v1/config'&&request.method==='GET')return reply(200,{data:{mode:'cloud',configured,provider:'deepseek',model:config.model,maxBatch:1,maxContentChars:QUOTA.maxChars,maxTopics:QUOTA.maxTopics,csrfToken:'public-demo',quota:QUOTA},request_id:requestId});
      if(url.pathname!=='/api/v1/analyze'||request.method!=='POST')throw new DomainError('NOT_FOUND','接口不存在。',404);
      if(!origin||!allowed.includes(origin))throw new DomainError('ORIGIN_DENIED','请通过 InsightFlow 页面提交分析。',403);
      if(!configured)throw new DomainError('AI_NOT_CONFIGURED','线上真实 AI 暂未启用；现有数据与模拟分析仍可使用。',503);
      const body=await readBody(request);
      if(!body||typeof body.content!=='string'||!body.content.trim()||[...body.content].length>QUOTA.maxChars||!Array.isArray(body.topics)||body.topics.length>QUOTA.maxTopics||body.topics.some(t=>!t||typeof t.id!=='string'||t.id.length>80||typeof t.name!=='string'||[...t.name].length>30)||new Set(body.topics.map(t=>t.id)).size!==body.topics.length||typeof body.requestId!=='string'||! /^[a-f0-9-]{36}$/i.test(body.requestId))throw new DomainError('INVALID_INPUT','公开体验每次仅分析一条不超过 1,500 字符的反馈，最多携带 30 个已确认主题。');
      const ip=request.headers.get('cf-connecting-ip');if(!ip)throw new DomainError('SERVICE_UNAVAILABLE','无法确认访问来源，未发送 AI 请求。',503);
      const day=new Date(Date.now()+8*3600000).toISOString().slice(0,10);
      const address='c'+await digest(`${config.apiKey}\n${day}\n${ip}`);
      await reserve(env.DB,day,address,body.requestId);
      // Reserve before calling. Failures/timeouts consume a slot; never auto-retry or refund unknown calls.
      const result=await analyzeWithDeepSeek(body.content,body.topics,{...config,maxTokens:700});
      const {output,metadata}=result;
      return reply(200,{data:{output,metadata},request_id:requestId});
    } catch(e) {
      const known=e instanceof DomainError;
      return reply(known?e.status:503,{error:{code:known?e.code:'SERVICE_UNAVAILABLE',message:known?e.message:'云端接口暂时不可用，未自动重试，请稍后再试。',retryable:false},request_id:requestId});
    }
  }
};
