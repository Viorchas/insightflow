export const REDACTION_VERSION = 'basic-pii-v1';

/** Basic exposure reduction only; not a guarantee that all personal data is removed. */
export function redactContent(content: string) {
  let matched = false;
  const replace = () => { matched = true; return '[已脱敏]'; };
  const text = content
    .replace(/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/gi, replace)
    .replace(/(?<!\d)(?:\+?86[ -]?)?1[3-9]\d{9}(?!\d)/g, replace);
  return { text, possibleSensitive: matched, version: REDACTION_VERSION };
}
