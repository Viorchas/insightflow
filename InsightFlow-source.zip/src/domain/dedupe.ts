import { createHash } from 'node:crypto';
import { DomainError } from './errors.ts';

export function dedupeKeys(fileHash: string, recordNo: number, source?: string | null, externalId?: string | null) {
  const hash = (parts: unknown[]) => createHash('sha256').update(JSON.stringify(parts)).digest('hex');
  const keys = [{ type: 'file_row', hash: hash([fileHash, recordNo]) }];
  if (externalId) {
    if (!source) throw new DomainError('SOURCE_REQUIRED', '外部 ID 必须包含来源');
    keys.push({ type: 'external', hash: hash([source, externalId]) });
  }
  return keys;
}
