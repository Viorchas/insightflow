import { DomainError } from './errors.ts';

export function parseFeedbackDate(value: string, timezone: 'Asia/Hong_Kong' | 'UTC' = 'Asia/Hong_Kong') {
  if (!value.trim()) return { timestamp: null, day: null };
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:[T ](\d{2}):(\d{2})(?::(\d{2})(?:\.(\d{1,3}))?)?(Z|[+-]\d{2}:\d{2})?)?$/.exec(value.trim());
  const fail = (): never => { throw new DomainError('INVALID_DATE', '日期需为有效 YYYY-MM-DD 或 ISO 时间，不能使用模糊日期'); };
  if (!m) return fail();
  const y=Number(m[1]),mo=Number(m[2]),d=Number(m[3]),h=Number(m[4]||0),mi=Number(m[5]||0),s=Number(m[6]||0);
  if (y<1900 || y>2200 || mo<1 || mo>12 || d<1 || d>new Date(Date.UTC(y,mo,0)).getUTCDate() || h>23 || mi>59 || s>59) return fail();
  const zone=m[8] || (timezone==='UTC'?'Z':'+08:00');
  if (zone!=='Z' && (Number(zone.slice(1,3))>14 || Number(zone.slice(4))>59 || (Number(zone.slice(1,3))===14 && Number(zone.slice(4))!==0))) return fail();
  const timestamp=new Date(`${m[1]}-${m[2]}-${m[3]}T${m[4]||'00'}:${m[5]||'00'}:${m[6]||'00'}.${(m[7]||'0').padEnd(3,'0')}${zone}`).toISOString();
  const day=new Intl.DateTimeFormat('sv-SE',{timeZone:'Asia/Hong_Kong',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(timestamp));
  return {timestamp,day};
}
