import { DomainError } from './errors.ts';
import { LIMITS, SENTIMENTS, ISSUE_TYPES, REVIEW_REASONS } from './config.ts';
import type { Sentiment, IssueType, ReviewReason } from './config.ts';

export type RequirementStatus = 'pending' | 'planned' | 'in_progress' | 'done' | 'rejected';
const transitions: Record<RequirementStatus, readonly RequirementStatus[]> = {
  pending: ['planned', 'rejected'],
  planned: ['pending', 'in_progress', 'rejected'],
  in_progress: ['planned', 'done'],
  done: ['in_progress'],
  rejected: ['pending'],
};

export function assertTransition(from: RequirementStatus, to: RequirementStatus, reopenConfirmed = false) {
  if (from === to) return;
  if (!transitions[from]?.includes(to)) throw new DomainError('INVALID_TRANSITION', '当前状态不允许该流转', 409);
  if ((from === 'done' || from === 'rejected') && !reopenConfirmed) {
    throw new DomainError('REOPEN_CONFIRMATION_REQUIRED', '请确认重新打开需求', 409);
  }
}

export function assertRevision(actual: number, expected: number) {
  if (!Number.isInteger(expected) || actual !== expected) {
    throw new DomainError('REVISION_CONFLICT', '内容已发生变化，请刷新后再提交', 409);
  }
}

export function assertBulkSelection(ids: string[]) {
  if (ids.length < 1 || ids.length > LIMITS.bulkItems) throw new DomainError('INVALID_SELECTION', `请选择 1—${LIMITS.bulkItems} 条记录`);
  if (new Set(ids).size !== ids.length) throw new DomainError('DUPLICATE_SELECTION', '选择中包含重复记录');
}

export type Classification = {
  topicId: string;
  summary: string;
  sentiment: Sentiment;
  issueType: IssueType;
};
export type ReviewDecision = {
  status: 'confirmed' | 'modified' | 'rejected';
  classification: Classification | null;
};

export function effectiveClassification(ai: Classification | null, review: ReviewDecision | null) {
  if (review?.status === 'rejected') return null;
  if (review) {
    if (!review.classification) throw new DomainError('INVALID_REVIEW', '已审核结果缺少分类');
    return { ...review.classification, origin: 'human' as const };
  }
  return ai ? { ...ai, origin: 'ai' as const } : null;
}

export function normalizeTopicName(value: string) {
  return value.normalize('NFKC').trim().replace(/\s+/gu, ' ').toLowerCase();
}

export type ImportCounts = {
  total: number; imported: number; skipped: number; invalid: number; writeFailed: number; pending: number;
};
export function assertImportCounts(counts: ImportCounts, terminal = false) {
  if (Object.values(counts).some(n => !Number.isInteger(n) || n < 0)) throw new DomainError('INVALID_COUNTS', '导入计数必须是非负整数', 500);
  const { total, imported, skipped, invalid, writeFailed, pending } = counts;
  if (total !== imported + skipped + invalid + writeFailed + pending || (terminal && pending !== 0)) {
    throw new DomainError('IMPORT_COUNT_MISMATCH', '导入计数不一致', 500);
  }
}

export type AiOutput = {
  summary: string;
  topic_id: string | null;
  proposed_topic_name: string | null;
  sentiment: Sentiment;
  issue_type: IssueType;
  review_reasons: ReviewReason[];
  evidence_quote: string;
};

export function validateAiOutput(value: unknown, redactedContent: string, confirmedTopicIds: ReadonlySet<string>): AiOutput {
  const fail = (message: string): never => { throw new DomainError('INVALID_AI_OUTPUT', message); };
  if (!value || typeof value !== 'object' || Array.isArray(value)) return fail('AI 输出不是对象');
  const v = value as Record<string, unknown>;
  const keys = ['summary', 'topic_id', 'proposed_topic_name', 'sentiment', 'issue_type', 'review_reasons', 'evidence_quote'];
  if (Object.keys(v).some(k => !keys.includes(k)) || keys.some(k => !(k in v))) return fail('AI 输出字段不符合约定');
  if (typeof v.summary !== 'string' || !v.summary.trim() || [...v.summary].length > 200) return fail('摘要为空或过长');
  const hasTopic = typeof v.topic_id === 'string' && v.topic_id.length > 0;
  const hasCandidate = typeof v.proposed_topic_name === 'string' && v.proposed_topic_name.trim().length > 0;
  if (hasTopic === hasCandidate) return fail('已有主题和候选主题必须二选一');
  if (hasTopic && (v.proposed_topic_name !== null || !confirmedTopicIds.has(v.topic_id as string))) return fail('主题不属于当前项目可用主题');
  if (hasCandidate && (v.topic_id !== null || [...(v.proposed_topic_name as string).trim()].length < 2 || [...(v.proposed_topic_name as string).trim()].length > 30)) return fail('候选主题字段非法');
  if (!SENTIMENTS.includes(v.sentiment as Sentiment) || !ISSUE_TYPES.includes(v.issue_type as IssueType)) return fail('分类枚举非法');
  if (!Array.isArray(v.review_reasons) || v.review_reasons.some(r => !REVIEW_REASONS.includes(r))) return fail('审核原因非法');
  if (hasCandidate && !v.review_reasons.includes('new_topic')) return fail('候选主题必须标记待审核原因');
  if (typeof v.evidence_quote !== 'string' || !v.evidence_quote.trim() || !redactedContent.includes(v.evidence_quote)) return fail('证据必须是输入正文的连续片段');
  return { ...(v as AiOutput), summary: v.summary.trim(), proposed_topic_name: hasCandidate ? (v.proposed_topic_name as string).trim() : null };
}
