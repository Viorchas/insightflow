import { DomainError } from './errors.ts';
import { LIMITS } from './config.ts';
import { parseFeedbackDate } from './dates.ts';

export type CsvTable = { headers: string[]; rows: string[][] };
export function parseCsv(bytes: Uint8Array): CsvTable {
  if (bytes.byteLength > LIMITS.uploadBytes) throw new DomainError('FILE_TOO_LARGE', '文件超过 5 MiB', 413);
  let text: string;
  try { text = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
  catch { throw new DomainError('INVALID_ENCODING', '请转换为 UTF-8 编码再上传'); }
  if (text.includes('\0')) throw new DomainError('INVALID_CSV', '文件含有不支持的二进制内容');
  const records: string[][] = [];
  let row: string[] = [], cell = '', quoted = false, afterQuote = false, started = false;
  const endCell = () => {
    row.push(cell); cell = ''; afterQuote = false; started = false;
    if (row.length > LIMITS.importColumns) throw new DomainError('TOO_MANY_COLUMNS', 'CSV 超过 50 列');
  };
  const endRow = () => {
    endCell(); records.push(row); row = [];
    if (records.length > LIMITS.importRows + 1) throw new DomainError('TOO_MANY_ROWS', 'CSV 超过 2,000 条数据行');
  };
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quoted) {
      if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; }
      else if (c === '"') { quoted = false; afterQuote = true; }
      else cell += c;
      continue;
    }
    if (afterQuote && c !== ',' && c !== '\r' && c !== '\n') throw new DomainError('INVALID_CSV', '引号关闭后存在非法字符');
    if (c === '"') {
      if (started || cell) throw new DomainError('INVALID_CSV', '未转义的引号');
      quoted = true; started = true;
    } else if (c === ',') endCell();
    else if (c === '\r' || c === '\n') { if (c === '\r' && text[i + 1] === '\n') i++; endRow(); }
    else { cell += c; started = true; }
  }
  if (quoted) throw new DomainError('INVALID_CSV', 'CSV 引号未闭合');
  if (cell || row.length || started || afterQuote) endRow();
  if (!records.length || records[0].every(c => !c.trim())) throw new DomainError('MISSING_HEADER', 'CSV 缺少有效表头');
  const headers = records.shift()!;
  if (records.some(r => r.length !== headers.length && !r.every(c => !c.trim()))) throw new DomainError('INVALID_CSV', '数据列数与表头不一致');
  return { headers, rows: records };
}

export type Mapping = { content: number; source?: number; external_id?: number; rating?: number; platform?: number; app_version?: number; feedback_at?: number };
export type RowResult = { recordNo: number; status: 'valid' | 'invalid' | 'empty'; values?: Record<string, string | number | null>; errors: string[] };
export function validateRows(table: CsvTable, mapping: Mapping, timezone: 'Asia/Hong_Kong' | 'UTC' = 'Asia/Hong_Kong'): RowResult[] {
  const positions = Object.values(mapping);
  if (!Number.isInteger(mapping.content) || positions.some(p => !Number.isInteger(p) || p < 0 || p >= table.headers.length) || new Set(positions).size !== positions.length) {
    throw new DomainError('INVALID_MAPPING', '正文映射缺失、列号无效或重复映射');
  }
  return table.rows.map((row, i) => {
    const recordNo = i + 2;
    if (row.every(v => !v.trim())) return { recordNo, status: 'empty', errors: [] };
    const get = (index?: number) => index === undefined ? '' : (row[index] ?? '').trim();
    const content = get(mapping.content);
    const errors: string[] = [];
    if (!content || [...content].length > LIMITS.contentChars) errors.push('正文为空或超过 5,000 字符');
    const values: Record<string, string | number | null> = { content, raw_text: row[mapping.content] ?? '' };
    try { const date=parseFeedbackDate(get(mapping.feedback_at),timezone);values.feedback_at=date.timestamp;values.date=date.day; }
    catch { errors.push('反馈时间无效，请使用 YYYY-MM-DD 或 ISO 时间'); }
    for (const [key, max] of [['source', 80], ['external_id', 200], ['platform', 40], ['app_version', 80]] as const) {
      const value = get(mapping[key]); values[key] = value || null;
      if ([...value].length > max) errors.push(`${key} 超过 ${max} 字符`);
    }
    if (values.external_id && !values.source) errors.push('有外部 ID 时必须提供来源');
    const rating = get(mapping.rating);
    values.rating = rating ? Number(rating) : null;
    if (rating && (!/^\d+(\.\d+)?$/.test(rating) || Number(rating) < 1 || Number(rating) > 5)) errors.push('评分须为 1—5 的数值');
    return { recordNo, status: errors.length ? 'invalid' : 'valid', values, errors };
  });
}

export function escapeCsvCell(value: unknown): string {
  let text = String(value ?? '');
  if (/^[\s]*[=+\-@]/u.test(text)) text = `'${text}`;
  return `"${text.replace(/"/g, '""')}"`;
}
