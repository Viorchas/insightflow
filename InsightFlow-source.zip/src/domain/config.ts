export const LIMITS = Object.freeze({
  uploadBytes: 5 * 1024 * 1024,
  importRows: 2_000,
  importColumns: 50,
  contentChars: 5_000,
  bulkItems: 200,
  aiTimeoutMs: 45_000,
  aiMaxAttempts: 3,
  pageSize: 20,
  maxPageSize: 100,
  confirmedTopics: 100,
});

export const SENTIMENTS = ['positive', 'neutral', 'negative', 'uncertain'] as const;
export const ISSUE_TYPES = ['feature_request', 'bug', 'usability', 'performance', 'other', 'uncertain'] as const;
export const REVIEW_REASONS = ['new_topic', 'multi_issue', 'insufficient_context', 'possible_sensitive', 'ambiguous'] as const;
export type Sentiment = typeof SENTIMENTS[number];
export type IssueType = typeof ISSUE_TYPES[number];
export type ReviewReason = typeof REVIEW_REASONS[number];
