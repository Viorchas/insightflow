# InsightFlow

面向软件 App 产品经理与独立开发者的反馈洞察与需求管理平台。完整开发基线见 `docs/DEVELOPMENT_SPEC.md`。

主流程：CSV 导入 → AI 主题归类 → 人工审核 → 洞察统计 → 需求跟进。

默认被分析产品为 **chatagent**：虚构的通用对话与 Agent 编程 AI 工作台。预置 24 条合成反馈、6 个主题及代码修改差异确认需求。场景设计见 `docs/CHATAGENT_SCENARIO.md`，不代表真实品牌反馈或用户研究成果。

当前提供可发布到 GitHub Pages 的免费交互演示。示例项目与反馈均为合成数据，预设结果和关键词模拟均有标记。静态部署不调用 DeepSeek，不含密钥，不跨设备同步。本地开发服务另支持显式确认的真实 DeepSeek 分析；完整服务端 MVP 尚未完成。进度见 `docs/IMPLEMENTATION_STATUS.md`。

## 本地打开

无需安装第三方依赖或数据库：

```powershell
node scripts/serve.mjs
```

打开打印的本地地址，默认 http://localhost:4173。可通过 PORT 环境变量改端口。浏览器数据按网址隔离，localhost 与 127.0.0.1 不共享演示数据。

## 验证已完成模块

使用支持直接运行 TypeScript 的 Node.js（当前验证环境 v24.19.0）：

```powershell
node --test tests/*.test.ts tests/*.test.mjs
node scripts/build.mjs
```

测试为合成数据，不代表真实用户效果或模型准确率。真实服务商密钥不得提交版本库或发送到聊天中。

## 免费发布与设计

建议建立名为 insightflow 的 GitHub 公共仓库，推送到 main，在 Settings → Pages 中选择 GitHub Actions。仓库自带发布工作流，测试与构建后发布 dist；以 GitHub 返回的真实网址为准。未来个人首页只需添加该项目链接。当前未创建远端仓库、未推送或公开发布。

免费技术链路、界面设计、部署步骤与异常分支见 `docs/FREE_DEPLOYMENT_AND_DESIGN.md`。

构建仅复制静态网页和允许的领域模块，不包含服务端适配器或 .env。路由为 hash，资源为相对路径，支持 GitHub Pages 仓库子路径。Node 类型剥离 API 会输出实验性提示，当前环境的用例与构建可正常运行。

## 演示限制

数据保存于浏览器 localStorage，清理站点数据或重置会丢失。支持 JSON 导出和校验后恢复为新项目。已支持日期/版本映射、组合筛选、摘要审核、需求内容及来源编辑、主题改名与归档恢复、导入逐行历史和本地真实分析记录。

仍未实现 PostgreSQL、服务器可靠队列、云端账号、跨设备同步与公开后台。分析记录用于解释本地执行结果，中断不自动重试，不能当作持续运行的服务器任务。模拟分类不代表真实模型效果，不应在简历中写成真实 AI 分析业绩。

## DeepSeek 配置

项目根目录 `.env` 已准备，仅在本地填写 `DEEPSEEK_API_KEY`。`.env` 已被版本控制忽略。`node scripts/serve.mjs` 启动时加载配置；填写后重启，再在页面“AI 配置”检查。在反馈列表选 1—10 条待审核反馈后，可明确确认发起真实分析。完整说明见 `docs/LOCAL_AI_SETUP.md`。

API 地址为 `https://api.deepseek.com`，模型 ID 为 `deepseek-flash`。依据官方文档 https://api-docs.deepseek.com/ 和 https://api-docs.deepseek.com/api/create-chat-completion/ 核对。实现使用非流式 JSON 输出与关闭思考模式，供应商建议仍需经过应用层校验和人工审核。

已使用一条合成反馈完成真实接口连通验证；自动化用例使用固定响应、不产生供应商费用。单条连通不等于全部模型质量或公开部署已经验证。密钥从不写入发布包。
