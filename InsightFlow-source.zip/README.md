# InsightFlow

面向软件 App 产品经理与独立开发者的反馈洞察与需求管理平台。完整开发基线见 `docs/DEVELOPMENT_SPEC.md`。

主流程：CSV 导入 → AI 主题归类 → 人工审核 → 洞察统计 → 需求跟进。

默认被分析产品为 **chatagent**：虚构的通用对话与 Agent 编程 AI 工作台。预置 204 条合成反馈、6 个主题及代码修改差异确认需求。场景设计见 `docs/CHATAGENT_SCENARIO.md`，不代表真实品牌反馈或用户研究成果。

当前已发布至 https://viorchas.github.io/insightflow/ 。免费指无需购买域名与服务器；公开网页通过 Cloudflare Workers 接入真实 DeepSeek，逐次确认并消耗作者额度。每次 1 条、1,500 字符，每地址每日 3 次、全站每日 10 次、累计 20 次后暂停；失败也占体验名额。示例、关键词模拟和真实分析分别标记。密钥仅存服务端，反馈仍存当前浏览器，不跨设备同步。完整服务端 MVP 尚未完成。接入说明见 `docs/CLOUD_AI_DEPLOYMENT.md`。

## 本地打开

无需安装第三方依赖或数据库：

```powershell
node scripts/serve.mjs
```

打开打印的本地地址，默认 http://localhost:4173。可通过 PORT 环境变量改端口。浏览器数据按网址隔离，localhost 与 127.0.0.1 不共享演示数据。

## 验证已完成模块

使用支持直接运行 TypeScript 的 Node.js（当前验证环境 v24.19.0）：

```powershell
node --test tests/*.test.ts tests/*.test.mjs
node scripts/build.mjs
```

测试为合成数据，不代表真实用户效果或模型准确率。真实服务商密钥不得提交版本库或发送到聊天中。

## 免费发布与设计

当前远端仓库为 https://github.com/Viorchas/insightflow ，Pages 使用 main 根目录的单文件 index.html；完整源码通过安全 ZIP 提供。本地 scripts/build-standalone.mjs 生成发布文件。源码中保留的 Actions 工作流是完整源码仓库的可选发布方式，不是当前远端发布方式。未来个人首页添加项目链接即可。

免费技术链路、界面设计、部署步骤与异常分支见 `docs/FREE_DEPLOYMENT_AND_DESIGN.md`。

构建仅复制静态网页和允许的领域模块，不包含服务端适配器或 .env。路由为 hash，资源为相对路径，支持 GitHub Pages 仓库子路径。Node 类型剥离 API 会输出实验性提示，当前环境的用例与构建可正常运行。

## 演示限制

数据保存于浏览器 localStorage，清理站点数据或重置会丢失。支持 JSON 导出和校验后恢复为新项目。已支持日期/版本映射、组合筛选、摘要审核、需求内容及来源编辑、主题改名与归档恢复、导入逐行历史和本地真实分析记录。

仍未实现 PostgreSQL、服务器可靠队列、云端账号与跨设备同步。云端后台目前仅处理真实分析和额度计数，分析记录保存在浏览器；关闭页面不保证继续运行，中断不自动重试。模拟分类不代表真实模型效果，不应在简历中写成真实 AI 分析业绩。

## DeepSeek 配置

项目根目录 `.env` 已准备，仅在本地填写 `DEEPSEEK_API_KEY`。`.env` 已被版本控制忽略。`node scripts/serve.mjs` 启动时加载配置；填写后重启，再在页面“AI 配置”检查。在反馈列表选 1—10 条待审核反馈后，可明确确认发起真实分析。完整说明见 `docs/LOCAL_AI_SETUP.md`。

API 地址为 `https://api.deepseek.com`，模型 ID 为 `deepseek-flash`。依据官方文档 https://api-docs.deepseek.com/ 和 https://api-docs.deepseek.com/api/create-chat-completion/ 核对。实现使用非流式 JSON 输出与关闭思考模式，供应商建议仍需经过应用层校验和人工审核。

2026-10-20 已从公开网页完成一条合成反馈的真实调用、摘要与证据保存；此前一次云端尝试因 Workers 不支持 redirect:error 而失败，已改为 manual 并拒绝 3xx，不自动转发认证头。Secret 名称支持 DEEPSEEK_API_KEY 与 deepseek_api_key。单条成功不代表整体模型准确率或并发可靠性已验证。密钥从不写入发布包。

## 下一阶段设计

用户已确认先完善演示，暂不做账号和云端反馈存储。需求、优先级和异常验收见 docs/PRODUCT_EVOLUTION_V1_1.md。新增模块目前仅完成设计，未上线。
