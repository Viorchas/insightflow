import {mkdtemp,mkdir,cp} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url));
await mkdir(path.join(root,'work'),{recursive:true});
const staging=await mkdtemp(path.join(root,'work/release-'));
for(const name of ['README.md','package.json','.gitignore','.gitattributes','.env.example','src','cloud','scripts','web','docs','tests','.github'])await cp(path.join(root,name),path.join(staging,name),{recursive:true});
console.log(staging);
