import { readFile, writeFile, mkdir, copyFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import './build.mjs';

const root=fileURLToPath(new URL('../',import.meta.url));
const staging=path.join(root,'work/publish');
await mkdir(staging,{recursive:true});
const files=['domain/config.js','domain/errors.js','domain/dates.js','domain/workflow.js','domain/csv.js','seed-expansion.mjs','demo-model.mjs','workspace.mjs','panels.mjs','cloud-config.mjs','app.mjs'];
const icon='data:image/svg+xml;base64,'+(await readFile(path.join(root,'web/favicon.svg'))).toString('base64');
const sample='data:text/csv;charset=utf-8;base64,'+(await readFile(path.join(root,'web/sample-feedback.csv'))).toString('base64');
let bundle='const __modules = Object.create(null);\n';
for(const file of files){
  let code=await readFile(path.join(root,'dist',file),'utf8');
  const names=[...code.matchAll(/\bexport\s+(?:async\s+)?(?:function|const|let|class)\s+(\w+)/g)].map(m=>m[1]);
  code=code.replace(/^import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"];?/gm,(_whole,bindings,relative)=>`const {${bindings}} = __modules[${JSON.stringify(path.posix.normalize(path.posix.join(path.posix.dirname(file),relative)))}];`);
  code=code.replace(/\bexport\s+(?=(?:async\s+)?(?:function|const|let|class)\b)/g,'');
  code=code.replaceAll('./favicon.svg',icon).replaceAll('./sample-feedback.csv',sample);
  bundle+=`__modules[${JSON.stringify(file)}] = (()=>{\n${code}\nreturn {${names.join(',')}};\n})();\n`;
}
let html=await readFile(path.join(root,'web/index.html'),'utf8');
const css=await readFile(path.join(root,'web/styles.css'),'utf8');
html=html.replace('./favicon.svg',icon).replace('<link rel="stylesheet" href="./styles.css">',`<style>${css}</style>`).replace('<script type="module" src="./app.mjs"></script>',`<script type="module">${bundle.replace(/<\/script/gi,'<\\/script')}</script>`);
await writeFile(path.join(staging,'index.html'),html);
await writeFile(path.join(root,'dist/singlefile.html'),html);
await writeFile(path.join(staging,'README.md'),'# InsightFlow\n\nAI 用户反馈洞察与需求管理交互演示，内置虚构 chatagent 产品的 204 条合成反馈。\n\n在线体验（启用 Pages 后）：https://viorchas.github.io/insightflow/\n\n本仓库根目录 index.html 为可直接托管的静态构建，界面资源已内嵌，无外部依赖。完整源码、开发文档和测试见 [InsightFlow-source.zip](./InsightFlow-source.zip)。\n\n页面支持独立的云端真实 AI 接口，需由作者配置并启用。关键词模拟不调用 AI；真实分析由访客明确确认，并受服务端限额约束。反馈保存在访客浏览器，密钥不包含在仓库或源码包中。\n\n演示数据不代表真实用户研究、客户案例或业务成绩。\n');
await copyFile(path.join(root,'outputs/InsightFlow_安全源码包.zip'),path.join(staging,'InsightFlow-source.zip'));
console.log('Standalone deployment prepared in work/publish (index.html, README.md, source archive).');
