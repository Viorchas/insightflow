import { randomBytes, timingSafeEqual } from 'node:crypto';
import { analyzeWithDeepSeek, readDeepSeekConfig } from '../src/ai/deepseek.ts';
import { DomainError } from '../src/domain/errors.ts';

/** Loopback-only development bridge. Not a public authentication or queue service. */
export function createLocalApi({ env = process.env, analyze = analyzeWithDeepSeek, now = Date.now } = {}) {
  const csrfToken = randomBytes(32).toString('hex');
  let active = false;
  let calls = [];
  function config() { return readDeepSeekConfig(env); }
  function send(res, status, data) {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
    res.end(JSON.stringify(data));
  }
  return async function handle(req, res, url) {
    if (!url.pathname.startsWith('/api/')) return false;
    const requestId = randomBytes(8).toString('hex');
    const fail = (status, code, message, retryable = false, retryAfterMs = null) => send(res, status, { error: { code, message, retryable, retryAfterMs }, request_id: requestId });
    try {
      const host = req.headers.host || '';
      if (!/^(localhost|127\.0\.0\.1):\d+$/.test(host) || !['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress)) {
        fail(403, 'LOCAL_ONLY', '此接口仅供本机使用'); return true;
      }
      if (req.headers.origin && req.headers.origin !== `http://${host}`) {
        fail(403, 'ORIGIN_DENIED', '不允许跨站请求'); return true;
      }
      if (req.headers['sec-fetch-site'] === 'cross-site') {
        fail(403, 'ORIGIN_DENIED', '不允许跨站请求'); return true;
      }
      if (url.pathname === '/api/v1/config' && req.method === 'GET') {
        const c = config();
        send(res, 200, { data: { mode: 'local', configured: Boolean(c.apiKey), provider: 'deepseek', model: c.model, maxBatch: 10, csrfToken }, request_id: requestId });
        return true;
      }
      if (url.pathname !== '/api/v1/analyze' || req.method !== 'POST') {
        fail(404, 'NOT_FOUND', '接口不存在'); return true;
      }
      const token = req.headers['x-insightflow-token'];
      if (typeof token !== 'string' || !/^[a-f0-9]{64}$/.test(token) || !timingSafeEqual(Buffer.from(token), Buffer.from(csrfToken))) {
        fail(403, 'INVALID_SESSION', '本地服务已重启或会话无效，请刷新页面'); return true;
      }
      if (!req.headers['content-type']?.startsWith('application/json')) {
        fail(415, 'CONTENT_TYPE_REQUIRED', '请求必须使用 JSON'); return true;
      }
      if (active) { fail(429, 'AI_BUSY', '本地已有分析请求，请等待完成', true, 2000); return true; }
      calls = calls.filter(t => now() - t < 60_000);
      if (calls.length >= 20) { fail(429, 'LOCAL_RATE_LIMIT', '本地每分钟最多分析 20 条，请稍后重试', true, 60_000); return true; }
      let bytes = 0, chunks = [];
      for await (const chunk of req) {
        bytes += chunk.length;
        if (bytes > 64 * 1024) { fail(413, 'BODY_TOO_LARGE', '分析输入过大'); return true; }
        chunks.push(chunk);
      }
      let body;
      try { body = JSON.parse(Buffer.concat(chunks).toString('utf8')); }
      catch { fail(400, 'INVALID_JSON', '请求正文不是有效 JSON'); return true; }
      if (!body || typeof body.content !== 'string' || !Array.isArray(body.topics) || body.topics.length > 100 || body.topics.some(t => !t || typeof t.id !== 'string' || typeof t.name !== 'string')) {
        fail(422, 'INVALID_INPUT', '反馈或主题输入格式无效'); return true;
      }
      const c = config();
      if (!c.apiKey) { fail(503, 'AI_NOT_CONFIGURED', '尚未配置密钥，请在本地 .env 填写 DEEPSEEK_API_KEY 并重启服务'); return true; }
      // Recheck after asynchronous body parsing; concurrent uploads must not bypass the gate.
      if (active) { fail(429, 'AI_BUSY', '本地已有分析请求，请等待完成', true, 2000); return true; }
      active = true; calls.push(now());
      try {
        const result = await analyze(body.content, body.topics, c);
        send(res, 200, { data: result, request_id: requestId });
      } finally { active = false; }
    } catch (e) {
      if (e instanceof DomainError) fail(e.status, e.code, e.message, Boolean(e.retryable), e.retryAfterMs ?? null);
      else fail(500, 'INTERNAL_ERROR', '本地分析服务发生错误，请稍后重试');
    }
    return true;
  };
}
