import { readFile,writeFile,mkdir } from 'node:fs/promises';
import { stripTypeScriptTypes } from 'node:module';
import path from 'node:path';
const root=new URL('../',import.meta.url);
const files=['src/domain/config.ts','src/domain/errors.ts','src/domain/redaction.ts','src/domain/workflow.ts','src/ai/deepseek.ts','cloud/worker.mjs'];
let bundle='const __modules=Object.create(null);\nasync function sha256(value){return [...new Uint8Array(await crypto.subtle.digest("SHA-256",new TextEncoder().encode(value)))].map(n=>n.toString(16).padStart(2,"0")).join("");}\n';
for(const file of files){
 let code=await readFile(new URL(file,root),'utf8');
 if(file.endsWith('.ts'))code=stripTypeScriptTypes(code,{mode:'strip'});
 code=code.replace(/^import.*from 'node:crypto';\r?\n/m,'').replace("createHash('sha256').update(requestInput).digest('hex')",'await sha256(requestInput)');
 const names=[...code.matchAll(/\bexport\s+(?:async\s+)?(?:function|const|let|class)\s+(\w+)/g)].map(m=>m[1]);
 code=code.replace(/^import\s*\{([^}]+)\}\s*from\s*['"]([^'"]+)['"];?/gm,(_all,bindings,relative)=>`const {${bindings}}=__modules[${JSON.stringify(path.posix.normalize(path.posix.join(path.posix.dirname(file),relative)))}];`);
 code=code.replace(/\bexport\s+(?=(?:async\s+)?(?:function|const|let|class)\b)/g,'');
 code=code.replace('export default {','const worker = {');
 bundle+=`__modules[${JSON.stringify(file)}]=(()=>{\n${code}\nreturn {${file==='cloud/worker.mjs'?'worker':names.join(',')}};\n})();\n`;
}
bundle+='export default __modules["cloud/worker.mjs"].worker;\n';
await mkdir(new URL('work/cloud/',root),{recursive:true});
await writeFile(new URL('work/cloud/worker.mjs',root),bundle);
console.log('Cloud Worker built without environment files or credentials.');
