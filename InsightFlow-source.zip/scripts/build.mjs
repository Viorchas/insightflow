import { mkdir, readFile, writeFile, cp } from 'node:fs/promises';
import { stripTypeScriptTypes } from 'node:module';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const root = fileURLToPath(new URL('../', import.meta.url));
const output = path.join(root, 'dist');
await mkdir(path.join(output, 'domain'), { recursive: true });
await cp(path.join(root, 'web'), output, { recursive: true });
// Explicit allowlist: never package server adapters, environment files or credentials.
for (const name of ['config', 'errors', 'workflow', 'csv', 'dates']) {
  const source = await readFile(path.join(root, 'src/domain', `${name}.ts`), 'utf8');
  const code = stripTypeScriptTypes(source, { mode: 'strip' }).replace(/from '(\.\/.+)\.ts'/g, "from '$1.js'");
  await writeFile(path.join(output, 'domain', `${name}.js`), code);
}
await writeFile(path.join(output, '.nojekyll'), '');
console.log('Built static GitHub Pages demo in dist/ (no API key, no server required).');
