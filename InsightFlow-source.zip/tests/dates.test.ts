import {test} from 'node:test';
import assert from 'node:assert/strict';
import {parseFeedbackDate} from '../src/domain/dates.ts';
import {parseCsv,validateRows} from '../src/domain/csv.ts';
test('日期按香港本地零点转换，带偏移输入按实际时间换算',()=>{
  assert.equal(parseFeedbackDate('2026-10-19').timestamp,'2026-10-18T16:00:00.000Z');
  assert.equal(parseFeedbackDate('2026-10-18T23:30:00Z').day,'2026-10-19');
  assert.equal(parseFeedbackDate('2026-10-19 10:30').timestamp,'2026-10-19T02:30:00.000Z');
  assert.equal(parseFeedbackDate('').day,null);
});
test('拒绝自动滚动日期、模糊格式、无效时间或偏移，支持闰年',()=>{
  for(const value of ['2026-02-30','2026-02-29','10/11/2026','2026-10-19T25:00','2026-10-19T10:00+14:30'])assert.throws(()=>parseFeedbackDate(value),{code:'INVALID_DATE'});
  assert.equal(parseFeedbackDate('2024-02-29').day,'2024-02-29');
});
test('CSV 日期逐行校验，空时间允许，错误时间仅使该行失败',()=>{
  const rows=validateRows(parseCsv(new TextEncoder().encode('正文,日期\n有效,2026-10-19\n无效,2026-02-30\n未知,')),{content:0,feedback_at:1});
  assert.deepEqual(rows.map(r=>r.status),['valid','invalid','valid']);
  assert.equal(rows[0].values?.date,'2026-10-19');assert.equal(rows[2].values?.feedback_at,null);
});
