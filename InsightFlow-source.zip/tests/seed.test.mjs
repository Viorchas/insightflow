import { test } from 'node:test';
import assert from 'node:assert/strict';
import { initialState, projectOf, isReviewed, classifyMock, loadState } from '../web/demo-model.mjs';
test('初始演示中已审核分类不能指向未确认的候选主题',()=>{
  const p=projectOf(initialState());
  for(const f of p.feedback.filter(isReviewed))assert.equal(p.topics.find(t=>t.id===f.topicId).status,'confirmed');
});
test('chatagent 示例有六个主题与204条合成反馈，需求来源可追溯',()=>{
  const p=projectOf(initialState());
  assert.equal(p.name,'chatagent');
  assert.equal(p.feedback.length,204);
  assert.equal(p.topics.length,6);
  assert.ok(p.requirements[0].sources.every(s=>p.feedback.some(f=>f.id===s.id)));
});
test('旧场景升级保留原反馈与需求，重复加载不添加第二个 chatagent',()=>{
  const old=initialState(), legacy=projectOf(old);
  delete legacy.seedKey;
  legacy.name='旧示例';
  legacy.feedback[0].content='已修改的旧反馈';
  const migrated=loadState({getItem:()=>JSON.stringify(old)});
  assert.equal(migrated.projects.length,2);
  assert.equal(projectOf(migrated).name,'chatagent');
  assert.equal(migrated.projects.find(p=>p.id===legacy.id).feedback[0].content,'已修改的旧反馈');
  const again=loadState({getItem:()=>JSON.stringify(migrated)});
  assert.equal(again.projects.length,2);
});
test('升级不会切走用户自建活动项目',()=>{
  const old=initialState(), custom=projectOf(old);
  delete custom.seedKey;custom.isSample=false;custom.name='我的项目';
  const upgraded=loadState({getItem:()=>JSON.stringify(old)});
  assert.equal(projectOf(upgraded).id,custom.id);
  assert.equal(upgraded.projects.length,2);
});
test('AI 平台反馈优先识别上下文与文件问题',()=>{
  assert.equal(classifyMock('长对话慢慢忘记上文').name,'上下文与对话记忆');
  assert.equal(classifyMock('PDF 回答需要页码引用').name,'文件理解与证据定位');
  assert.equal(classifyMock('Agent 修改代码前预览差异').name,'Agent 编程与修改控制');
});
