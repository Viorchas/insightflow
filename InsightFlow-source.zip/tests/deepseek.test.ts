import { test } from 'node:test';
import assert from 'node:assert/strict';
import { analyzeWithDeepSeek, readDeepSeekConfig } from '../src/ai/deepseek.ts';
const config = { ...readDeepSeekConfig({}), apiKey: 'test-only-not-a-real-key' };
const valid = { summary: '验证码失败', topic_id: null, proposed_topic_name: '验证码问题', sentiment: 'negative', issue_type: 'bug', review_reasons: ['new_topic'], evidence_quote: '收不到验证码' };
const okTransport = (output: unknown = valid, finish = 'stop'): typeof fetch => async () => new Response(JSON.stringify({ model: 'deepseek-flash', choices: [{ finish_reason: finish, message: { content: JSON.stringify(output) } }] }));

test('请求使用已确认模型、JSON 模式；身份数据脱敏，密钥不进入正文和元数据', async () => {
  const fake: typeof fetch = async (url, init) => {
    assert.equal(url, 'https://api.deepseek.com/chat/completions');
    const payload = JSON.parse(init!.body as string);
    assert.equal(payload.model, 'deepseek-flash');
    assert.equal(payload.thinking.type, 'disabled');
    assert.equal(payload.response_format.type, 'json_object');
    assert.ok(!String(init!.body).includes('someone@example.com'));
    assert.ok(!String(init!.body).includes(config.apiKey));
    return okTransport()(url, init);
  };
  const result = await analyzeWithDeepSeek('someone@example.com 收不到验证码 13812345678', [], config, fake);
  assert.ok(result.output.review_reasons.includes('possible_sensitive'));
  assert.ok(!result.redactedContent.includes('13812345678'));
  assert.ok(!JSON.stringify(result.metadata).includes(config.apiKey));
});

test('缺少密钥时明确失败，不静默使用模拟结果', async () => {
  await assert.rejects(analyzeWithDeepSeek('内容', [], readDeepSeekConfig({}), async () => { throw new Error('不应发送'); }), { code: 'AI_NOT_CONFIGURED' });
});

test('429 遵守 Retry-After；401 不自动重试；供应商正文不外泄', async () => {
  const limited: typeof fetch = async () => new Response('private provider body', { status: 429, headers: { 'Retry-After': '30' } });
  await assert.rejects(analyzeWithDeepSeek('内容', [], config, limited), { code: 'AI_RATE_LIMITED', retryable: true, retryAfterMs: 30_000 });
  await assert.rejects(analyzeWithDeepSeek('内容', [], config, async () => new Response('private provider body', { status: 401 })), { code: 'AI_AUTH_ERROR', retryable: false });
});

test('截断、非法 JSON 与伪造证据不作为有效分类', async () => {
  await assert.rejects(analyzeWithDeepSeek('收不到验证码', [], config, okTransport(valid, 'length')), { code: 'INVALID_AI_OUTPUT' });
  await assert.rejects(analyzeWithDeepSeek('收不到验证码', [], config, okTransport({ ...valid, evidence_quote: '收入下降' })), { code: 'INVALID_AI_OUTPUT' });
  await assert.rejects(analyzeWithDeepSeek('收不到验证码', [], config, async () => new Response('bad-json')), { code: 'INVALID_AI_OUTPUT' });
});

test('超时返回可重试错误，不泄露底层异常', async () => {
  const fake: typeof fetch = async (_url, init) => {
    await new Promise<void>((_resolve, reject) => {
      const timer = setTimeout(() => reject(new Error('transport failed to abort')), 1000);
      init!.signal!.addEventListener('abort', () => { clearTimeout(timer); reject(new Error('sensitive internals')); }, { once: true });
    });
    return new Response();
  };
  await assert.rejects(analyzeWithDeepSeek('内容', [], { ...config, timeoutMs: 10 }, fake), { code: 'AI_TIMEOUT', retryable: true });
});

test('拒绝任意第三方地址，避免误把密钥发送到未确认服务', async () => {
  await assert.rejects(analyzeWithDeepSeek('内容', [], { ...config, baseUrl: 'https://example.com' }, okTransport()), { code: 'AI_NOT_CONFIGURED' });
});
