import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createServer } from 'node:http';
import { createLocalApi } from '../scripts/local-api.mjs';

async function withServer(options, run) {
  const handler = createLocalApi(options);
  const server = createServer(async(req,res)=>{if(!await handler(req,res,new URL(req.url,'http://localhost')))res.writeHead(404).end();});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const base=`http://127.0.0.1:${server.address().port}`;
  try { await run(base); } finally { server.closeAllConnections(); await new Promise(resolve=>server.close(resolve)); }
}
test('配置接口只返回就绪状态，绝不返回密钥',async()=>{
  await withServer({env:{DEEPSEEK_API_KEY:'test-only-secret'}},async base=>{
    const r=await fetch(base+'/api/v1/config');const text=await r.text();
    assert.equal(r.status,200);assert.ok(!text.includes('test-only-secret'));
    const body=JSON.parse(text);assert.equal(body.data.configured,true);assert.equal(body.data.csrfToken.length,64);
  });
});
test('未配置密钥、跨站请求和缺失令牌均不调用供应商',async()=>{
  let invoked=0;
  await withServer({env:{},analyze:async()=>{invoked++;}},async base=>{
    const config=await(await fetch(base+'/api/v1/config')).json();
    const headers={'Content-Type':'application/json','x-insightflow-token':config.data.csrfToken};
    let r=await fetch(base+'/api/v1/analyze',{method:'POST',headers,body:JSON.stringify({content:'测试',topics:[]})});
    assert.equal((await r.json()).error.code,'AI_NOT_CONFIGURED');
    r=await fetch(base+'/api/v1/analyze',{method:'POST',headers:{...headers,Origin:'https://other.example'},body:'{}'});
    assert.equal(r.status,403);
    r=await fetch(base+'/api/v1/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
    assert.equal(r.status,403);assert.equal(invoked,0);
  });
});
test('接口返回适配器结果；失败不泄露底层错误',async()=>{
  await withServer({env:{DEEPSEEK_API_KEY:'test-only'},analyze:async(content)=>{
    if(content==='fail')throw Error('private secret or raw input');
    return {output:{summary:'模拟服务响应'},metadata:{provider:'test'}};
  }},async base=>{
    const cfg=await(await fetch(base+'/api/v1/config')).json();
    const post=content=>fetch(base+'/api/v1/analyze',{method:'POST',headers:{'Content-Type':'application/json','x-insightflow-token':cfg.data.csrfToken},body:JSON.stringify({content,topics:[]})});
    let r=await post('success');assert.equal(r.status,200);assert.equal((await r.json()).data.output.summary,'模拟服务响应');
    r=await post('fail');const text=await r.text();assert.equal(r.status,500);assert.ok(!text.includes('private secret'));
  });
});
test('无效 JSON 和超限请求不会进入模型',async()=>{
  let invoked=0;
  await withServer({env:{DEEPSEEK_API_KEY:'test-only'},analyze:async()=>{invoked++;}},async base=>{
    const cfg=await(await fetch(base+'/api/v1/config')).json();
    const headers={'Content-Type':'application/json','x-insightflow-token':cfg.data.csrfToken};
    let r=await fetch(base+'/api/v1/analyze',{method:'POST',headers,body:'bad-json'});
    assert.equal(r.status,400);
    r=await fetch(base+'/api/v1/analyze',{method:'POST',headers,body:JSON.stringify({content:'a'.repeat(70_000),topics:[]})});
    assert.equal(r.status,413);assert.equal(invoked,0);
  });
});
test('本地并发保护阻止第二个同时进行的付费调用',async()=>{
  let release,entered;
  const started=new Promise(resolve=>entered=resolve);
  await withServer({env:{DEEPSEEK_API_KEY:'test-only'},analyze:async()=>{entered();await new Promise(resolve=>release=resolve);return {output:{summary:'done'}};}},async base=>{
    const cfg=await(await fetch(base+'/api/v1/config')).json();
    const post=()=>fetch(base+'/api/v1/analyze',{method:'POST',headers:{'Content-Type':'application/json','x-insightflow-token':cfg.data.csrfToken},body:JSON.stringify({content:'测试',topics:[]})});
    const first=post();await started;
    try { const second=await post();assert.equal(second.status,429);assert.equal((await second.json()).error.code,'AI_BUSY'); }
    finally {release();}
    assert.equal((await first).status,200);
  });
});
