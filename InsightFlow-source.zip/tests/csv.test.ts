import { test } from 'node:test';
import assert from 'node:assert/strict';
import { parseCsv, validateRows, escapeCsvCell } from '../src/domain/csv.ts';
import { dedupeKeys } from '../src/domain/dedupe.ts';
const bytes = (text: string) => new TextEncoder().encode(text);

test('正确解析 BOM、引号内换行和双引号，保留原始记录序号', () => {
  const table = parseCsv(bytes('\uFEFF正文,评分\r\n"加载慢\n还会出现""错误""",1\r\n'));
  assert.deepEqual(table.headers, ['正文', '评分']);
  assert.equal(table.rows[0][0], '加载慢\n还会出现"错误"');
  assert.equal(validateRows(table, { content: 0, rating: 1 })[0].recordNo, 2);
});

test('拒绝损坏 CSV、非法编码和列数不匹配', () => {
  assert.throws(() => parseCsv(bytes('正文\n"未关闭')), { code: 'INVALID_CSV' });
  assert.throws(() => parseCsv(new Uint8Array([0xff, 0xfe])), { code: 'INVALID_ENCODING' });
  assert.throws(() => parseCsv(bytes('正文,评分\n内容,1,多余')), { code: 'INVALID_CSV' });
});

test('空正文、错误评分和空白行分别返回，不静默导入', () => {
  const result = validateRows(parseCsv(bytes('正文,评分\n,2\n内容,100\n,\n正常,4')), { content: 0, rating: 1 });
  assert.deepEqual(result.map(r => r.status), ['invalid', 'invalid', 'empty', 'valid']);
});

test('外部来源去重不受同文影响，哈希避免字段拼接歧义', () => {
  assert.notEqual(dedupeKeys('x', 2, 'a:b', 'c')[1].hash, dedupeKeys('x', 2, 'a', 'b:c')[1].hash);
  assert.notEqual(dedupeKeys('x', 2)[0].hash, dedupeKeys('x', 3)[0].hash);
  assert.throws(() => dedupeKeys('x', 2, null, 'id'), { code: 'SOURCE_REQUIRED' });
});

test('导出错误报告不能直接执行公式', () => {
  assert.equal(escapeCsvCell('=SUM(1,2)'), '"\'=SUM(1,2)"');
  assert.equal(escapeCsvCell('普通"内容'), '"普通""内容"');
});
