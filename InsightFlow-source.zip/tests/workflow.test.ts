import { test } from 'node:test';
import assert from 'node:assert/strict';
import { assertTransition, assertRevision, assertImportCounts, assertBulkSelection, effectiveClassification, validateAiOutput, normalizeTopicName } from '../src/domain/workflow.ts';

test('需求状态不能跳过规划直接完成，重新打开必须确认', () => {
  assert.throws(() => assertTransition('pending', 'done'), { code: 'INVALID_TRANSITION' });
  assert.throws(() => assertTransition('done', 'in_progress'), { code: 'REOPEN_CONFIRMATION_REQUIRED' });
  assert.doesNotThrow(() => assertTransition('done', 'in_progress', true));
});

test('审核冲突及批量选择异常必须在写入前被拦截', () => {
  assert.throws(() => assertRevision(2, 1), { code: 'REVISION_CONFLICT' });
  assert.throws(() => assertBulkSelection(['a', 'a']), { code: 'DUPLICATE_SELECTION' });
  assert.throws(() => assertBulkSelection([]), { code: 'INVALID_SELECTION' });
});

test('被拒绝结果不回退到 AI；重新分析不会覆盖人工结果', () => {
  const ai = { topicId: 'new', summary: '新建议', sentiment: 'negative' as const, issueType: 'bug' as const };
  assert.equal(effectiveClassification(ai, { status: 'rejected', classification: null }), null);
  assert.equal(effectiveClassification(ai, { status: 'modified', classification: { ...ai, topicId: 'human' } })?.topicId, 'human');
  assert.equal(effectiveClassification(ai, null)?.origin, 'ai');
});

test('导入完成必须计数守恒且不存在待处理行', () => {
  assert.doesNotThrow(() => assertImportCounts({ total: 10, imported: 5, skipped: 2, invalid: 2, writeFailed: 1, pending: 0 }, true));
  assert.throws(() => assertImportCounts({ total: 10, imported: 5, skipped: 2, invalid: 2, writeFailed: 0, pending: 1 }, true), { code: 'IMPORT_COUNT_MISMATCH' });
});

test('AI 不得引用其他项目主题或伪造原文证据', () => {
  const output = { summary: '验证码失败', topic_id: 'own', proposed_topic_name: null, sentiment: 'negative', issue_type: 'bug', review_reasons: [], evidence_quote: '收不到验证码' };
  const topics = new Set(['own']);
  assert.equal(validateAiOutput(output, '我收不到验证码', topics).topic_id, 'own');
  assert.throws(() => validateAiOutput({ ...output, topic_id: 'other-project' }, '我收不到验证码', topics), { code: 'INVALID_AI_OUTPUT' });
  assert.throws(() => validateAiOutput({ ...output, evidence_quote: '导致百万损失' }, '我收不到验证码', topics), { code: 'INVALID_AI_OUTPUT' });
});

test('候选主题必须明确待审核，不得同时匹配已有主题', () => {
  const candidate = { summary: '加载慢', topic_id: null, proposed_topic_name: '加载速度', sentiment: 'negative', issue_type: 'performance', review_reasons: ['new_topic'], evidence_quote: '加载很慢' };
  assert.equal(validateAiOutput(candidate, '加载很慢', new Set()).proposed_topic_name, '加载速度');
  assert.throws(() => validateAiOutput({ ...candidate, review_reasons: [] }, '加载很慢', new Set()), { code: 'INVALID_AI_OUTPUT' });
  assert.equal(normalizeTopicName('  Ａpp   登录  '), 'app 登录');
});
