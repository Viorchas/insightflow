import { test } from 'node:test';
import assert from 'node:assert/strict';
import { initialState, projectOf, effective, reviewFeedback, createRequirement, saveState, loadState, STORAGE_KEY } from '../web/demo-model.mjs';

test('候选主题不允许隐式审核；拒绝后不参与有效分类',()=>{
  const p=projectOf(initialState());
  const f=p.feedback.find(f=>f.topicId==='files');
  assert.throws(()=>reviewFeedback(p,f.id,f.revision,'confirmed'),/先在主题页确认/);
  reviewFeedback(p,f.id,f.revision,'rejected');
  assert.equal(effective(f),false);
});
test('需求创建要求确认未审核来源，且创建来源快照不会随分类变化',()=>{
  const p=projectOf(initialState()), f=p.feedback.find(f=>f.review==='pending');
  const fields={title:'排查登录',description:'来自合成数据',priority:'unset'};
  assert.throws(()=>createRequirement(p,fields,[f.id]),/未经审核/);
  const req=createRequirement(p,fields,[f.id],true), original=req.sources[0].topicName;
  f.topicId='context';f.content='后来改动的反馈';
  assert.equal(req.sources[0].topicName,original);
  assert.notEqual(req.sources[0].content,f.content);
});
test('重复或无效来源、空标题、过长描述不能创建需求',()=>{
  const p=projectOf(initialState()), f=p.feedback[0];
  const fields={title:'标题',priority:'medium'};
  assert.throws(()=>createRequirement(p,fields,[f.id,f.id],true),/不重复/);
  assert.throws(()=>createRequirement(p,fields,['nonexistent'],true),/来源反馈/);
  assert.throws(()=>createRequirement(p,{...fields,title:'  '},[f.id],true),/标题/);
  assert.throws(()=>createRequirement(p,{...fields,description:'a'.repeat(5001)},[f.id],true),/描述/);
});
test('存储失败不能报告保存成功；损坏数据不静默重置',()=>{
  assert.throws(()=>saveState({setItem(){throw Error('QuotaExceeded');}},initialState()),/未保存/);
  assert.throws(()=>loadState({getItem(){return JSON.stringify({version:1,projects:[]});}}),/无法读取/);
});
test('本地存储刷新后保留数据；修订冲突被拒绝',()=>{
  let stored;
  const storage={setItem(k,v){assert.equal(k,STORAGE_KEY);stored=v;},getItem(){return stored;}};
  const state=initialState(),p=projectOf(state),f=p.feedback[0];
  reviewFeedback(p,f.id,0,'confirmed');
  assert.throws(()=>reviewFeedback(p,f.id,0,'confirmed'),/已变化/);
  saveState(storage,state);
  assert.equal(projectOf(loadState(storage)).feedback[0].review,'confirmed');
});
