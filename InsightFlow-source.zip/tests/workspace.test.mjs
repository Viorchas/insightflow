import {test} from 'node:test';
import assert from 'node:assert/strict';
import {initialState,projectOf,reviewFeedback} from '../web/demo-model.mjs';
import {renameTopic,setTopicStatus,updateRequirement,matchesFeedback,validateBackup,mergeBackup,recoverInterruptedRuns} from '../web/workspace.mjs';

test('主题改名不改需求来源快照，重名与过期修订不能保存',()=>{
  const p=projectOf(initialState()), original=p.requirements[0].sources[0].topicName;
  renameTopic(p,'coding',0,'Agent 修改安全与确认');
  assert.equal(p.requirements[0].sources[0].topicName,original);
  assert.throws(()=>renameTopic(p,'coding',0,'过期修改'),/内容已变化/);
  assert.throws(()=>renameTopic(p,'context',0,'回答可靠性与引用'),/名称已存在/);
});
test('归档保留反馈数量和历史关联，可恢复且校验修订',()=>{
  const p=projectOf(initialState()), count=p.feedback.length;
  setTopicStatus(p,'coding',0,'archived');
  assert.equal(p.feedback.length,count);assert.equal(p.feedback[0].topicId,'coding');
  setTopicStatus(p,'coding',1,'confirmed');assert.equal(p.topics[0].status,'confirmed');
  assert.throws(()=>setTopicStatus(p,'coding',0,'archived'),/内容已变化/);
});
test('编辑需求保留老快照；新增未审核来源需确认；不允许移除全部来源',()=>{
  const p=projectOf(initialState()),req=p.requirements[0],old=req.sources[0];
  p.feedback.find(f=>f.id===old.id).content='原文发生变化';
  const fields={title:'调整后的需求',description:'编辑说明',priority:'high'},ids=[old.id,p.feedback[0].id];
  assert.throws(()=>updateRequirement(p,req.id,0,fields,ids),/未审核/);
  updateRequirement(p,req.id,0,fields,ids,true);
  assert.equal(req.sources[0].content,old.content);assert.equal(req.priority,'high');
  assert.throws(()=>updateRequirement(p,req.id,1,fields,[]),/必须保留/);
});
test('日期范围排除未知日期，审核口径与分析状态可组合',()=>{
  const f={content:'测试反馈',date:'2026-10-19',review:'confirmed',analysisStatus:'succeeded',topicId:'coding'};
  const params=new URLSearchParams({from:'2026-10-19',to:'2026-10-19',scope:'reviewed',topic:'coding'});
  assert.equal(matchesFeedback(f,params),true);
  assert.equal(matchesFeedback({...f,date:null},params),false);
  assert.equal(matchesFeedback({...f,review:'pending'},params),false);
  assert.equal(matchesFeedback({...f,analysisStatus:'failed'},params),false);
});
test('备份恢复为新项目，不覆盖已有数据；项目内关联完整',()=>{
  const current=initialState(),backup=initialState(),originalId=current.activeProjectId;
  const merged=mergeBackup(current,backup);
  assert.equal(current.projects.length,1);assert.equal(merged.projects.length,2);
  assert.equal(merged.projects[0].id,originalId);assert.notEqual(merged.activeProjectId,backup.activeProjectId);
  assert.doesNotThrow(()=>validateBackup(merged));
});
test('恶意 ID、无效日期、断裂来源和损坏结构都不能恢复',()=>{
  for(const mutate of [s=>s.projects[0].feedback[0].id='" onclick="bad',s=>s.projects[0].feedback[0].date='2026-02-30',s=>s.projects[0].requirements[0].sources[0].id='missing',s=>s.projects[0].topics=[null]]){
    const data=initialState();mutate(data);assert.throws(()=>validateBackup(data),/备份格式/);
  }
});
test('异常退出的旧分析只标记未知，不自动重新发送；新请求不被另一标签误判',()=>{
  const state=initialState(),p=projectOf(state),now=Date.now();
  p.analysisRuns=[{id:'old',status:'running',createdAt:new Date(now-120000).toISOString(),items:[{id:p.feedback[0].id,status:'running'},{id:p.feedback[1].id,status:'queued'},{id:p.feedback[2].id,status:'succeeded'}]},{id:'active',status:'running',createdAt:new Date(now).toISOString(),items:[]}];
  assert.equal(recoverInterruptedRuns(state,now),true);
  assert.deepEqual(p.analysisRuns[0].items.map(i=>i.status),['unknown','not_started','succeeded']);
  assert.equal(p.analysisRuns[1].status,'running');
});
test('未分析反馈不能伪装为已审核分类',()=>{
  const p=projectOf(initialState()),f=p.feedback[0];f.analysisStatus='queued';
  assert.throws(()=>reviewFeedback(p,f.id,0,'confirmed'),/先完成分析/);
  assert.equal(f.review,'pending');
});
test('备份中的主题修订和导入记录号不能携带可执行文本',()=>{
  const data=initialState();data.projects[0].topics[0].revision='" onclick="x';assert.throws(()=>validateBackup(data),/备份格式/);
  const other=initialState();other.projects[0].imports.push({id:'batch',fileName:'sample.csv',createdAt:new Date().toISOString(),total:1,imported:1,invalid:0,skipped:0,rows:[{recordNo:'<img src=x onerror=bad>',outcome:'new',errors:[]}]});assert.throws(()=>validateBackup(other),/备份格式/);
});
