# 线上真实 AI 接入

## 路线修正

用户确认“免费”指无需购买域名或服务器，允许少量使用自己的 DeepSeek API 额度。GitHub Pages 页面 + Cloudflare Workers Free 接口 + D1 Free 额度计数，使用平台子域名。真实分析由用户逐次确认；模拟作为独立选项保留，不静默降级。

## 当前代码

- cloud/worker.mjs：公网 API、Origin 限制、有限输入、D1 原子计数、DeepSeek 调用。
- scripts/build-cloud.mjs：使用既有适配器与校验规则打包，不读取 .env。
- cloud/wrangler.jsonc：非密钥配置；数据库创建后加入 DB 绑定。
- web/cloud-config.mjs：仅公开接口地址，无密钥。

接口：GET /api/v1/config，POST /api/v1/analyze。后者携带 content、topics、UUID requestId。请求大小上限 16 KiB；反馈最多 1,500 字符，最多 30 个已确认主题；输出最多 700 token。每次一次供应商调用，不自动重试。

## 初始额度

- 每个访问地址每天最多 3 次、全站每天 10 次、累计 20 次；按香港日期切换每日计数。
- D1 单条条件 UPDATE 在调用前占用名额，多实例和刷新不重置。
- 失败、超时、输出校验失败也占名额，因为供应商可能已处理。存储不可用时拒绝调用。
- 同一个 requestId 不重复发送；达到累计上限后需要作者主动调整并部署。
- 每日保存加盐哈希后的地址计数，不存原始 IP、反馈正文、模型响应或密钥。
- Origin/CORS 是浏览器来源限制，不是用户认证；防支出主要依靠持久的全站累计硬限额。
- API 费用仍由 DeepSeek 计费；次数和 token 上限不是人民币金额承诺。

## 密钥

创建 Worker 后，由用户在 Settings → Variables and Secrets 中新增类型 Secret、名称 DEEPSEEK_API_KEY，填写本地已有密钥。不要写入源码、普通变量或聊天。不从浏览器读出已存密钥。AI_ENABLED=false 可关闭新调用。

## 发布顺序

1. 构建云端产物。
2. Cloudflare 官方工具登录授权（用户确认权限）。
3. 创建独立 D1 额度数据库，加入 DB 绑定并部署。
4. 配置接口先返回 configured=false；验证公网服务和网页连接。
5. 网页与安全源码包同步到 GitHub Pages。
6. 用户填写服务端 Secret 后，少量合成反馈真实调用验收。

当前不提供账号、云端反馈存储或持久分析队列。已经创建 Worker 并不表示真实 AI 已启用；需以配置状态、D1 绑定及调用结果为准。

## 本轮部署结果（2026-10-19）

- Cloudflare 账号及官方 Wrangler 授权完成，使用限定的 Workers/D1 权限。
- insightflow-api 已部署至 https://insightflow-api.viorchas.workers.dev 。D1 额度库已创建并绑定 DB。
- GitHub Pages 已发布云端连接版本（仓库提交 2783b0b）；公开页面与配置接口均返回 HTTP 200。
- 浏览器已显示“云端接口已连接 / 真实 AI 暂未启用”。截至本次交付，配置接口 configured=false，等待用户在服务端填写 DEEPSEEK_API_KEY Secret。
- 已实现每次 1 条、1,500 字符、每日每地址 3 次、全站每日 10 次、累计 20 次的限额；本轮尚未用真实密钥验证云端调用，也未宣称额度并发用例通过。
- 本轮执行构建、语法和公开配置检查，未新增付费调用。此前本地真实调用成功不能代替本轮云端验收。
- 网页反馈继续存储在访客浏览器；D1 仅用于额度计数，不是云端反馈数据库。

## 线上真实调用验收（2026-10-20）

- 用户已填写 Secret，实际变量名为 deepseek_api_key；云端接口兼容该名称和标准大写名称，配置接口 configured=true。
- 首次从公开网页发起单条合成反馈分析失败；查明 Workers 不支持 redirect:error。适配器改为 manual，3xx 仍拒绝，不转发认证头到重定向地址。
- 修复部署后，公开网页再次发送同一条合成反馈，显示成功 1、失败 0。详情保留 DeepSeek 真实分析来源、摘要、原文证据和 1 个真实分析版本；审核状态仍为待审核。
- D1 只读查询确认本次 used=2、total=2，累计体验名额剩 18；失败次数仍保守计入限额。这里不把名额数等同于供应商计费次数。
- 本轮没有读取或输出 Secret 值。单条成功不代表总体质量、并发限制或全部异常路径已完成验收。
