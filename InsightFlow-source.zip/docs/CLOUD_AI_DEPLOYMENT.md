# 线上真实 AI 接入

## 路线修正

用户确认“免费”指无需购买域名或服务器，允许少量使用自己的 DeepSeek API 额度。GitHub Pages 页面 + Cloudflare Workers Free 接口 + D1 Free 额度计数，使用平台子域名。真实分析由用户逐次确认；模拟作为独立选项保留，不静默降级。

## 当前代码

- cloud/worker.mjs：公网 API、Origin 限制、有限输入、D1 原子计数、DeepSeek 调用。
- scripts/build-cloud.mjs：使用既有适配器与校验规则打包，不读取 .env。
- cloud/wrangler.jsonc：非密钥配置；数据库创建后加入 DB 绑定。
- web/cloud-config.mjs：仅公开接口地址，无密钥。

接口：GET /api/v1/config，POST /api/v1/analyze。后者携带 content、topics、UUID requestId。请求大小上限 16 KiB；反馈最多 1,500 字符，最多 30 个已确认主题；输出最多 700 token。每次一次供应商调用，不自动重试。

## 初始额度

- 每个访问地址每天最多 3 次、全站每天 10 次、累计 20 次；按香港日期切换每日计数。
- D1 单条条件 UPDATE 在调用前占用名额，多实例和刷新不重置。
- 失败、超时、输出校验失败也占名额，因为供应商可能已处理。存储不可用时拒绝调用。
- 同一个 requestId 不重复发送；达到累计上限后需要作者主动调整并部署。
- 每日保存加盐哈希后的地址计数，不存原始 IP、反馈正文、模型响应或密钥。
- Origin/CORS 是浏览器来源限制，不是用户认证；防支出主要依靠持久的全站累计硬限额。
- API 费用仍由 DeepSeek 计费；次数和 token 上限不是人民币金额承诺。

## 密钥

创建 Worker 后，由用户在 Settings → Variables and Secrets 中新增类型 Secret、名称 DEEPSEEK_API_KEY，填写本地已有密钥。不要写入源码、普通变量或聊天。不从浏览器读出已存密钥。AI_ENABLED=false 可关闭新调用。

## 发布顺序

1. 构建云端产物。
2. Cloudflare 官方工具登录授权（用户确认权限）。
3. 创建独立 D1 额度数据库，加入 DB 绑定并部署。
4. 配置接口先返回 configured=false；验证公网服务和网页连接。
5. 网页与安全源码包同步到 GitHub Pages。
6. 用户填写服务端 Secret 后，少量合成反馈真实调用验收。

当前不提供账号、云端反馈存储或持久分析队列。已经创建 Worker 并不表示真实 AI 已启用；需以配置状态、D1 绑定及调用结果为准。
