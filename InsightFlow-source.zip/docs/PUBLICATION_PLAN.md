# viorchas 的 GitHub Pages 发布计划

账号：Viorchas。公开仓库：https://github.com/Viorchas/insightflow 。已创建并提交演示文件。

访问地址：https://viorchas.github.io/insightflow/ 。已发布，HTTP 200，浏览器确认渲染 chatagent 示例并可筛出 12 条待审核反馈。

本地已建立 main 分支并只选取应用源码、文档、合成数据、用例和 GitHub Actions 配置。排除 .env、work、outputs、dist 等本机文件。部署时由 Actions 构建 dist，只上传静态网页，真实模型密钥不进入发布包。

实际首次发布使用浏览器上传，并配置 Pages 为 main 分支根目录（Deploy from a branch）。公开仓库根目录有 index.html（单文件静态构建）、README.md、InsightFlow-source.zip（源码快照）。源代码本地保留；源码包附带的 Actions 工作流是后续改为源码构建部署时的可选方案，当前线上没有运行该自定义工作流。

单文件构建由 scripts/build-standalone.mjs 生成，内嵌样式、浏览器模块、SVG 图标与 CSV 示例，已做脚本语法和本地页面验证。网页不含 .env 或本机浏览器记录。源代码压缩包采用允许列表生成，排除 .env、work、outputs。GitHub 个人主页不必先创建，未来添加链接即可。

公开演示不连接本地 DeepSeek 后台，访客不消耗本地账户额度。用户浏览器数据、反馈导入和真实密钥不随源码上传。
