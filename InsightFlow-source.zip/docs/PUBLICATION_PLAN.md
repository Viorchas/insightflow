# viorchas 的 GitHub Pages 发布计划

账号：viorchas。目标仓库：viorchas/insightflow（尚未创建）。

预期访问地址：https://viorchas.github.io/insightflow/ 。此为计划地址，尚未发布，不代表已经可用。

本地已建立 main 分支并只选取应用源码、文档、合成数据、用例和 GitHub Actions 配置。排除 .env、work、outputs、dist 等本机文件。部署时由 Actions 构建 dist，只上传静态网页，真实模型密钥不进入发布包。

待用户在 GitHub 登录 viorchas 后，创建公共 insightflow 仓库、推送代码、设置 Pages Source 为 GitHub Actions，然后运行和验证发布。GitHub 个人主页不必先创建，未来添加链接即可。

公开演示不连接本地 DeepSeek 后台，访客不消耗本地账户额度。用户浏览器数据、反馈导入和真实密钥不随源码上传。
